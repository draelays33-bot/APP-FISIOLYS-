import { jsPDF } from 'jspdf';
import { ClinicConfig, Service } from '../types';
import { DEFAULT_DOCTOR_CPF, getDoctorCpf } from './securityUtils';
import { ReceiptData } from './printUtils';
import { generateQRCodeDataUrl, getCheckInUrl, getGoogleReviewUrl, getPublicAppUrl } from './qrUtils';

export type QRTemplateType = 'checkin' | 'review' | 'app' | 'all';

export interface GenerateQRPDFOptions {
  type: QRTemplateType;
  clinic: ClinicConfig;
  patientName?: string;
  patientPhone?: string;
  customQrDataUrl?: string;
  customTargetUrl?: string;
  customUrl?: string;
  customTitle?: string;
}

const formatCurrency = (val: number): string => {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);
};

const formatDatePtBR = (dateStr: string): string => {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  }
  return dateStr;
};

/**
 * Generates a crisp, vector-sharp PDF document for Fisiolys official receipts
 */
export async function createReceiptPDF(
  receipt: ReceiptData,
  clinic: Partial<ClinicConfig>,
  docCpf?: string
): Promise<{ doc: jsPDF; blob: Blob; file: File; fileName: string }> {
  const activeDoctorCpf = docCpf || getDoctorCpf(clinic.managerCpf || DEFAULT_DOCTOR_CPF);
  const nowStr = new Date().toLocaleDateString('pt-BR');
  const clinicName = clinic.name || 'Fisiolys Fisioterapia e Pilates';
  const managerName = clinic.managerName || 'Dra. Elays Marinho';
  const crefito = clinic.managerCrefito || 'CREFITO-12';
  const address = clinic.address || 'Av. Coronel José Porfírio, nº 3025 - Recreio';
  const city = clinic.city || 'Altamira - Pará';
  const phone = clinic.phone || '(93) 99126-5006';

  const sanitizedPatient = receipt.patientName.replace(/[^a-zA-Z0-9]/g, '_').slice(0, 25);
  const fileName = `Recibo_${receipt.receiptNumber}_${sanitizedPatient}.pdf`;

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const margin = 18;
  const contentWidth = pageWidth - margin * 2; // 174mm
  let y = 18;

  // Background card outer border
  doc.setDrawColor(35, 55, 43); // #23372B
  doc.setLineWidth(0.8);
  doc.roundedRect(margin, y, contentWidth, 260, 4, 4);

  // Top header banner background
  doc.setFillColor(35, 55, 43); // #23372B
  doc.roundedRect(margin, y, contentWidth, 32, 4, 4, 'F');
  // Overlap square for bottom corners of header
  doc.rect(margin, y + 20, contentWidth, 12, 'F');

  // Gold accent bar below header
  doc.setFillColor(208, 167, 59); // #D0A73B
  doc.rect(margin, y + 32, contentWidth, 1.5, 'F');

  // Brand Header in Gold / Off-white
  doc.setTextColor(245, 238, 211); // #F5EED3
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(20);
  doc.text('FISIOLYS', margin + 10, y + 14);

  doc.setTextColor(208, 167, 59); // #D0A73B
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('FISIOTERAPIA & PILATES', margin + 10, y + 21);

  doc.setTextColor(200, 215, 205);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.text(`${address} • ${city}`, margin + 10, y + 27);

  // Header Right side - Receipt Badge
  doc.setFillColor(208, 167, 59); // #D0A73B
  doc.roundedRect(pageWidth - margin - 52, y + 8, 44, 8, 2, 2, 'F');
  doc.setTextColor(24, 39, 30);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text(receipt.receiptNumber, pageWidth - margin - 30, y + 13.5, { align: 'center' });

  doc.setTextColor(245, 238, 211);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.text(`Emissão: ${nowStr}`, pageWidth - margin - 8, y + 23, { align: 'right' });

  y += 40;

  // Doctor credentials banner
  doc.setFillColor(243, 247, 244); // #F3F7F4
  doc.setDrawColor(200, 220, 208);
  doc.setLineWidth(0.4);
  doc.roundedRect(margin + 5, y, contentWidth - 10, 16, 2, 2, 'FD');

  doc.setTextColor(24, 39, 30);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text(managerName, margin + 10, y + 6.5);

  doc.setTextColor(75, 100, 85);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text(`Fisioterapeuta Responsável • ${crefito}`, margin + 10, y + 11.5);

  doc.setTextColor(24, 39, 30);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text(`CPF: ${activeDoctorCpf}`, pageWidth - margin - 10, y + 6.5, { align: 'right' });

  doc.setTextColor(75, 100, 85);
  doc.setFont('helvetica', 'normal');
  doc.text(`WhatsApp: ${phone}`, pageWidth - margin - 10, y + 11.5, { align: 'right' });

  y += 24;

  // Title of the Document
  doc.setTextColor(35, 55, 43);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text('RECIBO OFICIAL DE PAGAMENTO', margin + 8, y);

  doc.setFillColor(208, 167, 59);
  doc.rect(margin + 8, y + 2, 35, 0.8, 'F');

  y += 10;

  // Data rows
  const drawRow = (label: string, value: string, isHighlight: boolean = false) => {
    doc.setFillColor(isHighlight ? 248 : 255, isHighlight ? 250 : 255, isHighlight ? 248 : 255);
    doc.setDrawColor(226, 232, 228);
    doc.setLineWidth(0.2);
    doc.rect(margin + 6, y, contentWidth - 12, 9, 'FD');

    doc.setTextColor(85, 107, 92);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.text(label, margin + 10, y + 6);

    doc.setTextColor(20, 31, 24);
    doc.setFont('helvetica', isHighlight ? 'bold' : 'normal');
    doc.setFontSize(9);
    doc.text(value, margin + 65, y + 6);

    y += 9;
  };

  drawRow('Recebemos de (Paciente):', receipt.patientName, true);
  if (receipt.patientCpf) {
    drawRow('CPF do Paciente:', receipt.patientCpf);
  }
  drawRow('Telefone de Contato:', receipt.patientPhone || 'Não informado');
  drawRow('Serviço / Atendimento:', receipt.serviceName, true);
  drawRow('Data do Atendimento / Ref.:', formatDatePtBR(receipt.date));
  drawRow('Forma de Pagamento:', receipt.paymentMethod);
  drawRow('Status do Pagamento:', 'QUITADO COM SUCESSO ✅', true);

  y += 6;

  // Value highlight box
  doc.setFillColor(237, 247, 240); // #EDF7F0
  doc.setDrawColor(46, 125, 74);
  doc.setLineWidth(0.6);
  doc.roundedRect(margin + 6, y, contentWidth - 12, 18, 3, 3, 'FD');

  doc.setTextColor(23, 77, 43);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('VALOR TOTAL QUITADO:', margin + 12, y + 11.5);

  doc.setTextColor(18, 68, 36);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text(formatCurrency(receipt.amount), pageWidth - margin - 12, y + 12.5, { align: 'right' });

  y += 24;

  // Legal / IRPF Tax Declaration Text
  doc.setFillColor(250, 251, 250);
  doc.setDrawColor(208, 167, 59); // Gold left bar
  doc.setLineWidth(0.6);
  doc.roundedRect(margin + 6, y, contentWidth - 12, 20, 1, 1, 'FD');
  doc.setFillColor(208, 167, 59);
  doc.rect(margin + 6, y, 1.8, 20, 'F');

  doc.setTextColor(75, 94, 81);
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  const legalText =
    'Declaramos para os devidos fins de direito, comprovação e dedução no Imposto de Renda (IRPF) que recebemos do(a) paciente acima identificado(a) o valor total supramencionado referente a serviços profissionais especializados de Fisioterapia e/ou Pilates.';
  const splitLegal = doc.splitTextToSize(legalText, contentWidth - 22);
  doc.text(splitLegal, margin + 12, y + 6);

  y += 24;

  if (receipt.notes) {
    doc.setTextColor(85, 107, 92);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text(`Observações: ${receipt.notes}`, margin + 8, y);
    y += 8;
  }

  // Signature section
  const sigY = 224;
  doc.setDrawColor(185, 203, 191);
  doc.setLineWidth(0.3);
  doc.line(margin + 6, sigY - 4, pageWidth - margin - 6, sigY - 4);

  // Left side signature notes
  doc.setTextColor(99, 117, 104);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text(address, margin + 8, sigY + 8);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.text(`${city} • Tel: ${phone}`, margin + 8, sigY + 13);
  doc.text('Documento timbrado com validade legal e fiscal.', margin + 8, sigY + 18);

  // Right side signature line
  const sigRightX = pageWidth - margin - 40;
  doc.setDrawColor(30, 51, 37);
  doc.setLineWidth(0.5);
  doc.line(sigRightX - 35, sigY + 6, sigRightX + 35, sigY + 6);

  doc.setTextColor(20, 31, 24);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text(managerName, sigRightX, sigY + 11, { align: 'center' });

  doc.setTextColor(85, 107, 92);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.text(`Fisioterapeuta Responsável • ${crefito}`, sigRightX, sigY + 15.5, { align: 'center' });

  doc.setTextColor(158, 127, 34);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text(`CPF: ${activeDoctorCpf}`, sigRightX, sigY + 20, { align: 'center' });

  // Footer bar
  doc.setFillColor(243, 247, 244);
  doc.rect(margin, 252, contentWidth, 8, 'F');
  doc.setTextColor(109, 128, 115);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.text(`🌿 ${clinicName}`, margin + 6, 257.5);
  doc.text(`Documento emitido eletronicamente em ${nowStr}`, pageWidth - margin - 6, 257.5, { align: 'right' });

  // Generate output blob and file
  const pdfBlob = doc.output('blob');
  const pdfFile = new File([pdfBlob], fileName, { type: 'application/pdf' });

  return { doc, blob: pdfBlob, file: pdfFile, fileName };
}

/**
 * Triggers direct download of the official PDF file
 */
export async function downloadReceiptPDF(
  receipt: ReceiptData,
  clinic: Partial<ClinicConfig>,
  docCpf?: string
): Promise<string> {
  const { blob, fileName } = await createReceiptPDF(receipt, clinic, docCpf);

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();

  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 2000);

  return fileName;
}

/**
 * Opens PDF in browser or viewer, and opens print dialog
 */
export async function printReceiptPDF(
  receipt: ReceiptData,
  clinic: Partial<ClinicConfig>,
  docCpf?: string
): Promise<void> {
  const { blob, fileName } = await createReceiptPDF(receipt, clinic, docCpf);
  const blobUrl = URL.createObjectURL(blob);

  // Open in a new tab or trigger direct download
  const printWindow = window.open(blobUrl, '_blank');
  if (!printWindow || printWindow.closed) {
    // If pop-up blocked or in iframe, trigger auto download
    const a = document.createElement('a');
    a.href = blobUrl;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(blobUrl);
    }, 2000);
  }
}

/**
 * Handles sharing receipt via WhatsApp, attaching the PDF file when supported
 * or downloading the PDF and opening WhatsApp with formatted text
 */
export async function shareReceiptViaWhatsApp(
  receipt: ReceiptData,
  clinic: Partial<ClinicConfig>,
  docCpf?: string
): Promise<{ sharedAsFile: boolean; fileName: string; phoneUsed: string }> {
  const { file, fileName, blob } = await createReceiptPDF(receipt, clinic, docCpf);
  const activeDoctorCpf = docCpf || getDoctorCpf(clinic.managerCpf || DEFAULT_DOCTOR_CPF);

  const cleanPhone = (receipt.patientPhone || '').replace(/\D/g, '');
  const phoneToUse = cleanPhone.length > 0 ? (cleanPhone.startsWith('55') ? cleanPhone : `55${cleanPhone}`) : '';

  const msg =
    `🧾 *RECIBO OFICIAL DE PAGAMENTO - ${clinic.name || 'Fisiolys'}*\n\n` +
    `Olá *${receipt.patientName}*! Segue em anexo o seu recibo em PDF e comprovante do atendimento:\n\n` +
    `📄 *Nº do Recibo:* ${receipt.receiptNumber}\n` +
    `🧘‍♀️ *Serviço/Atendimento:* ${receipt.serviceName}\n` +
    `💰 *Valor Quitado:* ${formatCurrency(receipt.amount)}\n` +
    `💳 *Forma de Pagamento:* ${receipt.paymentMethod}\n` +
    `🗓️ *Data:* ${formatDatePtBR(receipt.date)}\n` +
    `📋 *Status:* Quitado com Sucesso ✅\n\n` +
    `🏥 *Profissional:* ${clinic.managerName || 'Dra. Elays Marinho'} (${clinic.managerCrefito || 'CREFITO-12'})\n` +
    `🪪 *CPF da Profissional:* ${activeDoctorCpf}\n` +
    `📍 *Endereço:* ${clinic.address} - ${clinic.city}\n\n` +
    `Agradecemos pela sua confiança! Guarde este recibo para seu controle e declaração de Imposto de Renda. ✨🌸`;

  // 1. Check if browser can share files natively (WhatsApp on iOS, Android, macOS Safari/Chrome)
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    try {
      await navigator.share({
        files: [file],
        title: `Recibo Oficial - ${receipt.patientName}`,
        text: msg,
      });
      return { sharedAsFile: true, fileName, phoneUsed: phoneToUse };
    } catch (err: unknown) {
      // User cancelled share sheet or share error -> fall back to auto-download + WhatsApp link
      console.log('Share cancelled or not completed, falling back to download + WhatsApp link', err);
    }
  }

  // 2. Fallback: Automatically download the PDF to patient/admin device AND open WhatsApp
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 2000);

  // Open WhatsApp with complete formatted text
  const waUrl = phoneToUse
    ? `https://api.whatsapp.com/send?phone=${phoneToUse}&text=${encodeURIComponent(msg)}`
    : `https://api.whatsapp.com/send?text=${encodeURIComponent(msg)}`;

  window.open(waUrl, '_blank');

  return { sharedAsFile: false, fileName, phoneUsed: phoneToUse };
}

/**
 * Generates Reception / Check-in / Google Review A4 Display Sign with QR Code
 */
export async function generateQRPDF(options: GenerateQRPDFOptions): Promise<jsPDF> {
  const { type, clinic, patientPhone } = options;
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  // Target URL based on type
  let targetUrl = options.customUrl || options.customTargetUrl || getPublicAppUrl(clinic.customAppUrl);
  let title = options.customTitle || 'ACESSE NOSSO APLICATIVO';
  let subtitle = 'Escaneie a câmera do seu celular para agendar e gerenciar suas sessões';
  let badgeText = 'PILATES & FISIOTERAPIA';

  if (type === 'checkin') {
    targetUrl = options.customUrl || options.customTargetUrl || getCheckInUrl(clinic.customAppUrl, patientPhone);
    title = options.customTitle || 'CONFIRME SUA PRESENÇA';
    subtitle = 'Aponte a câmera do seu celular no QR Code para realizar seu Check-in automático';
    badgeText = 'TOTEM DE CHECK-IN DIGITAL';
  } else if (type === 'review') {
    targetUrl = options.customUrl || options.customTargetUrl || getGoogleReviewUrl(clinic.googleReviewUrl, clinic.address, clinic.city);
    title = options.customTitle || 'AVALIE SUA EXPERIÊNCIA NO GOOGLE';
    subtitle = 'Sua opinião é muito valiosa! Escaneie para nos avaliar com 5 estrelas';
    badgeText = 'AVALIAÇÃO 5 ESTRELAS ⭐⭐⭐⭐⭐';
  }

  // Border & Header
  doc.setFillColor(35, 55, 43); // #23372B
  doc.rect(0, 0, pageWidth, 42, 'F');

  doc.setFillColor(208, 167, 59); // Gold bar
  doc.rect(0, 42, pageWidth, 2.5, 'F');

  doc.setTextColor(245, 238, 211);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(24);
  doc.text('FISIOLYS', pageWidth / 2, 20, { align: 'center' });

  doc.setTextColor(208, 167, 59);
  doc.setFontSize(10);
  doc.text('FISIOTERAPIA & PILATES • DRA. ELAYS MARINHO', pageWidth / 2, 29, { align: 'center' });

  doc.setTextColor(200, 220, 210);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.text(`${clinic.address} • ${clinic.city}`, pageWidth / 2, 36, { align: 'center' });

  // Badge
  doc.setFillColor(208, 167, 59);
  doc.roundedRect(pageWidth / 2 - 45, 55, 90, 9, 3, 3, 'F');
  doc.setTextColor(24, 39, 30);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text(badgeText, pageWidth / 2, 61, { align: 'center' });

  // Big Title
  doc.setTextColor(35, 55, 43);
  doc.setFontSize(16);
  doc.text(title, pageWidth / 2, 76, { align: 'center' });

  // Subtitle
  doc.setTextColor(80, 100, 90);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  const splitSub = doc.splitTextToSize(subtitle, 160);
  doc.text(splitSub, pageWidth / 2, 85, { align: 'center' });

  // QR Code Image
  let qrDataUrl = options.customQrDataUrl;
  if (!qrDataUrl) {
    qrDataUrl = await generateQRCodeDataUrl(targetUrl);
  }
  const qrSize = 95;
  const qrX = (pageWidth - qrSize) / 2;
  const qrY = 100;

  // QR Outer Box
  doc.setFillColor(255, 255, 255);
  doc.setDrawColor(208, 167, 59);
  doc.setLineWidth(1.2);
  doc.roundedRect(qrX - 6, qrY - 6, qrSize + 12, qrSize + 12, 6, 6, 'FD');

  if (qrDataUrl) {
    doc.addImage(qrDataUrl, 'PNG', qrX, qrY, qrSize, qrSize);
  }

  // Instructions
  let curY = qrY + qrSize + 16;
  doc.setFillColor(243, 247, 244);
  doc.setDrawColor(200, 220, 210);
  doc.setLineWidth(0.4);
  doc.roundedRect(25, curY, pageWidth - 50, 26, 3, 3, 'FD');

  doc.setTextColor(35, 55, 43);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text('Como utilizar:', 32, curY + 7);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(70, 90, 80);
  doc.text('1. Abra a câmera ou leitor de QR Code no seu smartphone', 32, curY + 13);
  doc.text('2. Aponte para o código acima e toque no link exibido', 32, curY + 18.5);
  doc.text('3. Concluído! Sem necessidade de baixar nada ou fila de espera', 32, curY + 23.5);

  // Footer
  doc.setFillColor(35, 55, 43);
  doc.rect(0, pageHeight - 16, pageWidth, 16, 'F');
  doc.setTextColor(245, 238, 211);
  doc.setFontSize(8);
  doc.text(
    `🌿 Fisiolys Clínica Integrada • Contato: ${clinic.phone || '(93) 99126-5006'}`,
    pageWidth / 2,
    pageHeight - 6.5,
    { align: 'center' }
  );

  return doc;
}

/**
 * Generates A4 PDF Services & Treatments Catalog
 */
export async function generateServicesCatalogPDF(
  clinic: ClinicConfig,
  services: Service[]
): Promise<jsPDF> {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 16;
  const contentWidth = pageWidth - margin * 2;

  // Header
  doc.setFillColor(35, 55, 43);
  doc.rect(0, 0, pageWidth, 38, 'F');
  doc.setFillColor(208, 167, 59);
  doc.rect(0, 38, pageWidth, 2, 'F');

  doc.setTextColor(245, 238, 211);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(20);
  doc.text('FISIOLYS - CATÁLOGO DE SERVIÇOS & PILATES', pageWidth / 2, 18, { align: 'center' });

  doc.setTextColor(208, 167, 59);
  doc.setFontSize(9);
  doc.text(`TABELA OFICIAL • ${clinic.managerName || 'Dra. Elays Marinho'} (CREFITO-12)`, pageWidth / 2, 26, {
    align: 'center',
  });

  doc.setTextColor(200, 220, 210);
  doc.setFontSize(7.5);
  doc.text(`${clinic.address} • ${clinic.city} • Tel: ${clinic.phone}`, pageWidth / 2, 33, {
    align: 'center',
  });

  let y = 48;

  // Services list
  services.forEach((srv, index) => {
    if (y > pageHeight - 35) {
      doc.addPage();
      y = 20;
    }

    doc.setFillColor(index % 2 === 0 ? 250 : 255, index % 2 === 0 ? 252 : 255, index % 2 === 0 ? 250 : 255);
    doc.setDrawColor(220, 230, 225);
    doc.setLineWidth(0.3);
    doc.roundedRect(margin, y, contentWidth, 18, 2, 2, 'FD');

    doc.setTextColor(35, 55, 43);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text(srv.name, margin + 5, y + 6.5);

    doc.setTextColor(18, 68, 36);
    doc.setFontSize(11);
    doc.text(formatCurrency(srv.price), pageWidth - margin - 5, y + 7, { align: 'right' });

    doc.setTextColor(90, 110, 95);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    const desc = srv.description || `Sessão personalizada • Duração: ${srv.durationMinutes || 50} min`;
    doc.text(desc.slice(0, 85), margin + 5, y + 13);

    y += 21;
  });

  // Footer
  doc.setFillColor(35, 55, 43);
  doc.rect(0, pageHeight - 12, pageWidth, 12, 'F');
  doc.setTextColor(245, 238, 211);
  doc.setFontSize(7.5);
  doc.text(
    `🌿 Fisiolys Clínica • Agendamentos pelo WhatsApp: ${clinic.phone || '(93) 99126-5006'}`,
    pageWidth / 2,
    pageHeight - 5,
    { align: 'center' }
  );

  return doc;
}
