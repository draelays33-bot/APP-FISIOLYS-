import React, { useState, useEffect } from 'react';
import { Service, ClinicConfig, Appointment, PaymentMethod, SlotInfo, FrequencyType, WeeklyDaySchedule } from '../../types';
import { api } from '../../services/api';
import { formatCurrency, formatDatePtBR, formatPhoneMask, generateWhatsAppMessage, getClinicMapUrl } from '../../utils/qrUtils';
import { getImageUrl } from '../../utils/imageUtils';
import { LoyaltyProgramSection } from './LoyaltyProgramSection';
import { TestimonialsSection } from './TestimonialsSection';
import { DownloadAppQRSection } from './DownloadAppQRSection';
import {
  Calendar as CalendarIcon,
  Clock,
  User,
  Phone,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  Sparkles,
  MapPin,
  MessageSquare,
  AlertCircle,
  FileText,
  ShieldCheck,
  Send,
  RefreshCw,
  Info,
  Award,
  Instagram,
  CreditCard,
  QrCode,
  Copy,
  ExternalLink,
  Check,
  Users,
  Navigation,
  Mail,
  Cake,
  Building,
  Home,
  Plus,
  Trash2,
  Repeat,
  CheckSquare
} from 'lucide-react';

interface PublicBookingProps {
  clinic: ClinicConfig;
  services: Service[];
  onBookingSuccess?: () => void;
  initialService?: Service | null;
  onNavigateToServices?: () => void;
  onNavigateToPatientPortal?: (tab?: 'checkin' | 'frequencia') => void;
}

const WEEKDAY_NAMES = [
  { day: 1, name: 'Segunda-feira', short: 'Seg' },
  { day: 2, name: 'Terça-feira', short: 'Ter' },
  { day: 3, name: 'Quarta-feira', short: 'Qua' },
  { day: 4, name: 'Quinta-feira', short: 'Qui' },
  { day: 5, name: 'Sexta-feira', short: 'Sex' },
  { day: 6, name: 'Sábado', short: 'Sáb' },
];

const STANDARD_TIMES = ['08:00', '09:00', '10:00', '14:00', '15:00', '16:00', '17:00', '18:00'];

export const PublicBooking: React.FC<PublicBookingProps> = ({
  clinic,
  services,
  onBookingSuccess,
  initialService,
  onNavigateToServices,
  onNavigateToPatientPortal,
}) => {
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Helper to format investment frequency per requested categories
  const getInvestmentTypeLabel = (category: string) => {
    if (category === 'pilates') return '(Mensal)';
    if (category === 'massoterapia' || category === 'fisioterapia') return '(Sessão)';
    return '(Sessão)';
  };

  const activeServices = services.filter((s) => s.active);

  // Service Selection
  const [selectedService, setSelectedService] = useState<Service | null>(
    initialService || (activeServices.length > 0 ? activeServices[0] : null)
  );

  // Frequency & Multi-day State
  const [frequencyType, setFrequencyType] = useState<FrequencyType>('2x_semana');

  // Weekly plan schedule state
  const [day1Weekday, setDay1Weekday] = useState<number>(2); // Terça
  const [day1Time, setDay1Time] = useState<string>('08:00');
  const [day2Weekday, setDay2Weekday] = useState<number>(4); // Quinta
  const [day2Time, setDay2Time] = useState<string>('08:00');
  const [day3Weekday, setDay3Weekday] = useState<number>(6); // Sábado
  const [day3Time, setDay3Time] = useState<string>('08:00');

  // Multi-dates specific list (for 'multiplos_dias')
  const [customMultiDates, setCustomMultiDates] = useState<{ date: string; time: string }[]>([]);

  // Single Session / Starting Date Selection
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('08:00');

  // Patient Registration Form State
  const [patientName, setPatientName] = useState<string>('');
  const [patientBirthDate, setPatientBirthDate] = useState<string>('');
  const [patientPhone, setPatientPhone] = useState<string>('');
  const [patientEmail, setPatientEmail] = useState<string>('');
  const [patientAddress, setPatientAddress] = useState<string>('');
  const [patientCity, setPatientCity] = useState<string>('Altamira - PA');
  const [patientCpf, setPatientCpf] = useState<string>('');
  const [patientNotes, setPatientNotes] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('pix');
  const [copiedPix, setCopiedPix] = useState<boolean>(false);

  // Slot Availability (for single session)
  const [slotsLoading, setSlotsLoading] = useState<boolean>(false);
  const [availableSlots, setAvailableSlots] = useState<SlotInfo[]>([]);
  const [selectedBlockedSlot, setSelectedBlockedSlot] = useState<SlotInfo | null>(null);
  const [slotError, setSlotError] = useState<string>('');

  // Submit State
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [submitError, setSubmitError] = useState<string>('');
  const [confirmedAppointment, setConfirmedAppointment] = useState<Appointment | null>(null);
  const [webhookStatus, setWebhookStatus] = useState<boolean | null>(null);

  // Auto-detect best frequency when service changes
  const applyServiceFrequencyDefaults = (srv: Service) => {
    const nameLower = srv.name.toLowerCase();
    const descLower = (srv.description || '').toLowerCase();

    if (nameLower.includes('12 sess') || nameLower.includes('3x') || descLower.includes('3x na semana') || descLower.includes('3 vezes')) {
      setFrequencyType('3x_semana');
      setDay1Weekday(1); // Seg
      setDay1Time('08:00');
      setDay2Weekday(3); // Qua
      setDay2Time('08:00');
      setDay3Weekday(5); // Sex
      setDay3Time('08:00');
    } else if (nameLower.includes('8 sess') || nameLower.includes('2x') || descLower.includes('2x na semana') || descLower.includes('2 vezes') || srv.category === 'pilates') {
      setFrequencyType('2x_semana');
      setDay1Weekday(2); // Ter
      setDay1Time('08:00');
      setDay2Weekday(4); // Qui
      setDay2Time('08:00');
    } else if (nameLower.includes('avaliação') || nameLower.includes('experimental') || srv.category === 'massoterapia') {
      setFrequencyType('sessao_unica');
    } else {
      setFrequencyType('2x_semana');
    }
  };

  // When initialService changes or when page mounts with an initialService, scroll directly to patient registration
  useEffect(() => {
    if (initialService) {
      setSelectedService(initialService);
      applyServiceFrequencyDefaults(initialService);
      setStep(1);

      // Smoothly focus on registration card
      setTimeout(() => {
        const el = document.getElementById('patient-registration-card');
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
          const input = document.getElementById('input-patient-name');
          if (input) input.focus();
        }
      }, 150);
    }
  }, [initialService]);

  // Set default initial date
  useEffect(() => {
    if (!selectedDate) {
      const getInitialBookingDate = () => {
        const d = new Date();
        // If Sunday (0), default to Monday
        if (d.getDay() === 0) {
          d.setDate(d.getDate() + 1);
        }
        return d.toISOString().split('T')[0];
      };
      const initDate = getInitialBookingDate();
      setSelectedDate(initDate);

      // Also initialize customMultiDates with 2 sample days if empty
      if (customMultiDates.length === 0) {
        const d2 = new Date(initDate + 'T00:00:00');
        d2.setDate(d2.getDate() + 2);
        if (d2.getDay() === 0) d2.setDate(d2.getDate() + 1);
        const yyyy = d2.getFullYear();
        const mm = String(d2.getMonth() + 1).padStart(2, '0');
        const dd = String(d2.getDate()).padStart(2, '0');
        const d2Str = `${yyyy}-${mm}-${dd}`;

        setCustomMultiDates([
          { date: initDate, time: '08:00' },
          { date: d2Str, time: '08:00' },
        ]);
      }
    }
  }, [activeServices]);

  // Jump to next day helper
  const handleJumpToNextAvailableDate = () => {
    const baseDate = selectedDate ? new Date(selectedDate + 'T00:00:00') : new Date();
    baseDate.setDate(baseDate.getDate() + 1);
    if (baseDate.getDay() === 0) {
      baseDate.setDate(baseDate.getDate() + 1); // skip Sunday
    }
    const yyyy = baseDate.getFullYear();
    const mm = String(baseDate.getMonth() + 1).padStart(2, '0');
    const dd = String(baseDate.getDate()).padStart(2, '0');
    setSelectedDate(`${yyyy}-${mm}-${dd}`);
  };

  // Generate quick 12-day date selection cards
  const getQuickDateOptions = () => {
    const list = [];
    const today = new Date();

    for (let i = 0; i < 12; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() + i);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      const dateStr = `${yyyy}-${mm}-${dd}`;

      const dayOfWeek = d.getDay();
      const dayNames = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
      const isSunday = dayOfWeek === 0;
      const isToday = i === 0;
      const isTomorrow = i === 1;

      let badge = dayNames[dayOfWeek];
      if (isToday) badge = 'HOJE';
      else if (isTomorrow) badge = 'AMANHÃ';

      list.push({
        dateStr,
        badge,
        dayNum: dd,
        monthNum: mm,
        dayOfWeekName: dayNames[dayOfWeek],
        isSunday,
        isToday,
      });
    }
    return list;
  };

  // Fetch available slots when service or date changes (primarily for single session)
  useEffect(() => {
    if (selectedService && selectedDate && frequencyType === 'sessao_unica') {
      fetchSlots(selectedDate, selectedService.id);
    }
  }, [selectedDate, selectedService, frequencyType]);

  const fetchSlots = async (date: string, serviceId: string) => {
    setSlotsLoading(true);
    setSlotError('');
    try {
      const res = await api.getAvailableSlots(date, serviceId);
      if (!res.available) {
        setSlotError(res.reason || 'Atendimento indisponível nesta data.');
        setAvailableSlots([]);
      } else {
        setAvailableSlots(res.slots);
      }
    } catch (err: any) {
      setSlotError('Não foi possível verificar os horários. Tente novamente.');
    } finally {
      setSlotsLoading(false);
    }
  };

  // Build the structured plan schedule and summary string
  const getPlanScheduleData = (): {
    selectedDaysSchedule: WeeklyDaySchedule[];
    planScheduleSummary: string;
    finalTime: string;
    finalDate: string;
    multipleDatesList?: { date: string; time: string }[];
  } => {
    const d1Name = WEEKDAY_NAMES.find((w) => w.day === day1Weekday)?.name || 'Segunda-feira';
    const d2Name = WEEKDAY_NAMES.find((w) => w.day === day2Weekday)?.name || 'Quarta-feira';
    const d3Name = WEEKDAY_NAMES.find((w) => w.day === day3Weekday)?.name || 'Sexta-feira';

    if (frequencyType === '2x_semana') {
      const schedule: WeeklyDaySchedule[] = [
        { dayOfWeek: day1Weekday, dayName: d1Name, time: day1Time },
        { dayOfWeek: day2Weekday, dayName: d2Name, time: day2Time },
      ];
      const summary = `Plano 2x por semana (${d1Name} às ${day1Time} e ${d2Name} às ${day2Time}) • Início: ${formatDatePtBR(selectedDate)}`;
      return {
        selectedDaysSchedule: schedule,
        planScheduleSummary: summary,
        finalTime: day1Time,
        finalDate: selectedDate,
      };
    }

    if (frequencyType === '3x_semana') {
      const schedule: WeeklyDaySchedule[] = [
        { dayOfWeek: day1Weekday, dayName: d1Name, time: day1Time },
        { dayOfWeek: day2Weekday, dayName: d2Name, time: day2Time },
        { dayOfWeek: day3Weekday, dayName: d3Name, time: day3Time },
      ];
      const summary = `Plano 3x por semana (${d1Name} às ${day1Time}, ${d2Name} às ${day2Time} e ${d3Name} às ${day3Time}) • Início: ${formatDatePtBR(selectedDate)}`;
      return {
        selectedDaysSchedule: schedule,
        planScheduleSummary: summary,
        finalTime: day1Time,
        finalDate: selectedDate,
      };
    }

    if (frequencyType === 'multiplos_dias') {
      const datesSummary = customMultiDates
        .map((d) => `${formatDatePtBR(d.date)} às ${d.time}`)
        .join(', ');
      const summary = `Múltiplos Dias (${customMultiDates.length} sessões): ${datesSummary}`;
      const firstDate = customMultiDates[0]?.date || selectedDate;
      const firstTime = customMultiDates[0]?.time || selectedTime || '08:00';
      return {
        selectedDaysSchedule: [],
        planScheduleSummary: summary,
        finalTime: firstTime,
        finalDate: firstDate,
        multipleDatesList: customMultiDates,
      };
    }

    // Single session
    return {
      selectedDaysSchedule: [],
      planScheduleSummary: `Sessão Única: ${formatDatePtBR(selectedDate)} às ${selectedTime} hs`,
      finalTime: selectedTime || '08:00',
      finalDate: selectedDate,
    };
  };

  // Add date to custom multi-dates
  const handleAddCustomDate = (dateStr: string) => {
    if (customMultiDates.some((d) => d.date === dateStr)) return;
    setCustomMultiDates([...customMultiDates, { date: dateStr, time: selectedTime || '08:00' }]);
  };

  const handleRemoveCustomDate = (index: number) => {
    setCustomMultiDates(customMultiDates.filter((_, idx) => idx !== index));
  };

  const handleUpdateCustomDateTime = (index: number, timeStr: string) => {
    const updated = [...customMultiDates];
    updated[index].time = timeStr;
    setCustomMultiDates(updated);
  };

  const handleNextStep = () => {
    if (!patientName.trim()) {
      setSubmitError('Por favor, informe seu Nome Completo no cadastro.');
      const el = document.getElementById('input-patient-name');
      if (el) el.focus();
      return;
    }
    if (!patientBirthDate.trim()) {
      setSubmitError('Por favor, informe sua Data de Nascimento (para felicitações e mimos de aniversário).');
      const el = document.getElementById('input-patient-birthdate');
      if (el) el.focus();
      return;
    }
    if (!patientPhone.trim() || patientPhone.trim().length < 8) {
      setSubmitError('Por favor, informe seu WhatsApp para confirmações e lembretes 2h antes.');
      const el = document.getElementById('input-patient-phone');
      if (el) el.focus();
      return;
    }
    if (!patientAddress.trim()) {
      setSubmitError('Por favor, informe seu Endereço completo (Rua, Número e Bairro).');
      const el = document.getElementById('input-patient-address');
      if (el) el.focus();
      return;
    }

    if (frequencyType === 'multiplos_dias' && customMultiDates.length === 0) {
      setSubmitError('Por favor, selecione ao menos 1 data para o atendimento no calendário.');
      return;
    }

    setSubmitError('');
    setStep(2);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePrevStep = () => {
    if (step === 2) {
      setStep(1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSubmitBooking = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!patientName.trim()) {
      setSubmitError('Por favor, digite seu Nome Completo.');
      return;
    }
    if (!patientBirthDate.trim()) {
      setSubmitError('Por favor, informe sua Data de Nascimento.');
      return;
    }
    if (!patientPhone.trim()) {
      setSubmitError('Por favor, informe seu WhatsApp.');
      return;
    }
    if (!patientAddress.trim()) {
      setSubmitError('Por favor, informe seu Endereço.');
      return;
    }
    if (!selectedService) {
      setSubmitError('Por favor, selecione um serviço.');
      return;
    }

    const { selectedDaysSchedule, planScheduleSummary, finalTime, finalDate, multipleDatesList } = getPlanScheduleData();

    setSubmitting(true);
    setSubmitError('');

    try {
      const result = await api.createAppointment({
        patientName,
        patientBirthDate,
        patientPhone,
        patientEmail,
        patientAddress,
        patientCity: patientCity || 'Altamira - PA',
        patientCpf,
        serviceId: selectedService.id,
        date: finalDate,
        time: finalTime,
        frequencyType,
        selectedDaysSchedule: selectedDaysSchedule.length > 0 ? selectedDaysSchedule : undefined,
        planScheduleSummary,
        multipleDates: multipleDatesList,
        notes: patientNotes ? `${patientNotes} • ${planScheduleSummary}` : planScheduleSummary,
        paymentMethod,
      });

      setConfirmedAppointment(result.appointment);
      setWebhookStatus(result.webhookSent);
      setStep(3);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      if (onBookingSuccess) onBookingSuccess();
    } catch (err: any) {
      setSubmitError(err.message || 'Erro ao realizar agendamento.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenWhatsAppConfirmation = () => {
    if (!confirmedAppointment) return;
    const cleanPhone = clinic.whatsapp.replace(/\D/g, '');
    const encodedMsg = generateWhatsAppMessage({
      clinicName: clinic.name,
      patientName: confirmedAppointment.patientName,
      serviceName: confirmedAppointment.serviceName,
      servicePrice: confirmedAppointment.servicePrice,
      date: confirmedAppointment.date,
      time: confirmedAppointment.time,
      address: clinic.address,
      paymentMethod: confirmedAppointment.paymentMethod || paymentMethod,
      planScheduleSummary: confirmedAppointment.planScheduleSummary,
    });

    window.open(`https://wa.me/${cleanPhone}?text=${encodedMsg}`, '_blank');
  };

  // Generate date picker min and max dates
  const todayStr = new Date().toISOString().split('T')[0];
  const maxDateObj = new Date();
  maxDateObj.setDate(maxDateObj.getDate() + 45);
  const maxDateStr = maxDateObj.toISOString().split('T')[0];

  const currentScheduleData = getPlanScheduleData();

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-slate-50/60 pb-12 pt-4 px-3 sm:px-6">
      <div className="max-w-3xl mx-auto">

        {/* Clinic Header Card */}
        <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-sm border border-[#C9D8CB] mb-6 relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-[#5F6D33] via-[#D0A73B] to-[#31523D]" />

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden shrink-0 border-2 border-[#D0A73B] shadow-sm bg-[#23372B]">
                <img
                  src="/src/assets/images/fisiolys_logo_brand_1785780140781.jpg"
                  alt="Logo Fisiolys Fisioterapia e Pilates"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#F5EED3] text-[#7E611D] border border-[#D0A73B]/30 mb-1.5">
                  <Sparkles className="w-3 h-3 text-[#D0A73B]" />
                  <span>Agendamento Online</span>
                </span>
                <h2 className="text-xl sm:text-2xl font-serif font-extrabold text-[#23372B] tracking-tight">
                  {clinic.name}
                </h2>
                <a
                  href={getClinicMapUrl(clinic.address, clinic.city)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs sm:text-sm text-[#31523D] hover:text-[#23372B] hover:underline mt-1 flex items-center space-x-1 group transition-colors"
                  title="Clique para abrir localização da clínica no Google Maps"
                >
                  <MapPin className="w-3.5 h-3.5 text-[#5F6D33] group-hover:text-[#D0A73B] shrink-0 transition-colors" />
                  <span className="font-medium">{clinic.address} - {clinic.city}</span>
                  <ExternalLink className="w-3 h-3 text-[#D0A73B] opacity-70 group-hover:opacity-100" />
                </a>
              </div>
            </div>

            {/* Contact, Location & Social Badges */}
            <div className="flex flex-wrap sm:flex-col items-start sm:items-end justify-start sm:justify-center gap-2 shrink-0">
              <a
                href={getClinicMapUrl(clinic.address, clinic.city)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-1.5 text-xs text-[#23372B] font-extrabold bg-[#D0A73B] hover:bg-[#b8912d] px-3.5 py-2 rounded-xl border border-[#D0A73B] transition-all shadow-2xs group"
                title="Abrir rota para a clínica via Google Maps"
              >
                <Navigation className="w-3.5 h-3.5 text-[#23372B] group-hover:rotate-45 transition-transform" />
                <span>Destino / Ver no Mapa</span>
              </a>

              <a
                href={`https://wa.me/${clinic.whatsapp.replace(/\D/g, '')}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center space-x-1.5 text-xs text-white font-bold bg-[#31523D] hover:bg-[#23372B] px-3.5 py-2 rounded-xl border border-[#D0A73B]/40 transition-all shadow-2xs"
              >
                <MessageSquare className="w-3.5 h-3.5 text-[#D0A73B]" />
                <span>WhatsApp: (93) 99126-5006</span>
              </a>

              <a
                href="https://instagram.com/fisiolysmarinho"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center space-x-1.5 text-xs text-[#23372B] font-bold bg-[#F5EED3] hover:bg-[#EBDC9C] px-3.5 py-2 rounded-xl border border-[#D0A73B]/50 transition-all shadow-2xs"
              >
                <Instagram className="w-4 h-4 text-[#E1306C]" />
                <span>@fisiolysmarinho</span>
              </a>
            </div>
          </div>

          {/* Practitioner Introduction Banner */}
          <div className="mt-5 pt-4 border-t border-[#E4EBE4] bg-gradient-to-r from-[#F4F7F4] via-white to-[#F4F7F4] rounded-xl p-4 flex flex-col sm:flex-row items-center space-y-3 sm:space-y-0 sm:space-x-4 border border-[#3D674C]/20 shadow-2xs">
            <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-2xl overflow-hidden shrink-0 border-2 border-[#D0A73B] shadow-md">
              <img
                src={getImageUrl("/src/assets/images/dra_elays_marinho_official_1785780100332.jpg")}
                alt="Dra. Elays Marinho"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="text-center sm:text-left flex-1">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <div>
                  <div className="flex items-center space-x-2 justify-center sm:justify-start">
                    <h3 className="text-lg font-serif font-bold text-[#23372B]">Dra. Elays Marinho</h3>
                    <span className="bg-[#D0A73B] text-[#23372B] text-[10px] font-extrabold px-2 py-0.5 rounded-md uppercase tracking-wider">
                      12 Anos de Experiência
                    </span>
                  </div>
                  <p className="text-xs font-bold text-[#D0A73B] uppercase tracking-wide">CREFITO: 208058</p>
                </div>
                <div className="flex flex-col sm:items-end items-center gap-1">
                  <span className="inline-flex items-center space-x-1 text-[11px] font-extrabold bg-[#23372B] text-[#F5EED3] px-3 py-1 rounded-full border border-[#D0A73B]/50 shadow-2xs">
                    <Award className="w-3.5 h-3.5 text-[#D0A73B]" />
                    <span>Fisioterapeuta Responsável</span>
                  </span>
                </div>
              </div>
              <div className="mt-2 space-y-1">
                <p className="text-xs font-semibold text-[#31523D] flex items-center justify-center sm:justify-start space-x-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#5F6D33] shrink-0" />
                  <span>Fisioterapeuta Especialista em Traumato-Ortopedia, Pediatria e ABA</span>
                </p>
                <p className="text-xs font-semibold text-[#31523D] flex items-center justify-center sm:justify-start space-x-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#5F6D33] shrink-0" />
                  <span>Especialista em Pilates Clínico, Biomecânico e Reabilitação Funcional</span>
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* QUICK CHECK-IN & RECEPTION TOTEM BANNER */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 bg-gradient-to-r from-[#1E3326] via-[#31523D] to-[#23372B] rounded-2xl text-white shadow-sm mb-6 border-2 border-emerald-500/40 gap-3">
          <div className="flex items-center space-x-3.5">
            <div className="w-11 h-11 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-black shrink-0 border border-emerald-400/30">
              <QrCode className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h4 className="text-xs sm:text-sm font-extrabold text-white">Chegou para seu atendimento de hoje?</h4>
                <span className="px-2 py-0.5 bg-emerald-500 text-emerald-950 text-[10px] font-black rounded-full uppercase">
                  Recepção
                </span>
              </div>
              <p className="text-xs text-slate-200 mt-0.5">
                Faça seu <strong>Check-in de Presença</strong> em poucos segundos pelo Totem ou QR Code.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onNavigateToPatientPortal?.('checkin')}
            className="w-full sm:w-auto px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-emerald-950 rounded-xl text-xs font-black transition-all shadow-xs flex items-center justify-center space-x-1.5 cursor-pointer shrink-0"
          >
            <span>📍 Fazer Check-in Agora</span>
          </button>
        </div>

        {/* Step Progress Bar */}
        {step < 3 && (
          <div className="bg-white rounded-xl p-3 sm:p-4 shadow-2xs border border-[#C9D8CB] mb-6">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-500 mb-2">
              <span className={step >= 1 ? "text-[#5F6D33] font-bold" : ""}>1. Cadastro & Dias do Tratamento</span>
              <span className={step >= 2 ? "text-[#5F6D33] font-bold" : ""}>2. Revisão & Pagamento</span>
              <span className={step >= 3 ? "text-[#5F6D33] font-bold" : ""}>3. Confirmação</span>
            </div>
            <div className="w-full bg-[#E4EBE4] h-2.5 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-[#5F6D33] to-[#D0A73B] h-full transition-all duration-300 ease-out"
                style={{ width: `${(step / 2) * 100}%` }}
              />
            </div>
          </div>
        )}

        {/* STEP 1: PATIENT REGISTRATION + FREQUENCY & MULTI-DAY SELECTION */}
        {step === 1 && (
          <div id="step-1-booking-container" className="space-y-6">

            {/* SEÇÃO 1: CADASTRO DO PACIENTE */}
            <div
              id="patient-registration-card"
              className="bg-white rounded-2xl p-5 sm:p-6 shadow-sm border-2 border-[#D0A73B]/70 relative overflow-hidden"
            >
              {/* Highlight Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-5 pb-4 border-b border-[#E4EBE4]">
                <div className="flex items-center space-x-3">
                  <span className="w-10 h-10 rounded-xl bg-[#31523D] text-[#D0A73B] flex items-center justify-center font-bold text-base shadow-xs shrink-0">
                    <User className="w-5 h-5" />
                  </span>
                  <div>
                    <h3 className="text-base sm:text-lg font-serif font-extrabold text-[#23372B] leading-tight flex items-center gap-2">
                      <span>1. Cadastro do Paciente</span>
                      <span className="text-[10px] bg-[#31523D] text-[#D0A73B] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                        Passo Obrigatório
                      </span>
                    </h3>
                    <p className="text-xs text-[#5F6D33] font-medium mt-0.5">
                      Preencha seus dados para abertura do prontuário, lembretes de sessão e mimos
                    </p>
                  </div>
                </div>

                {selectedService && (
                  <div className="bg-[#F5EED3] border border-[#D0A73B]/50 px-3 py-1.5 rounded-xl self-start sm:self-auto flex items-center space-x-2">
                    <Sparkles className="w-3.5 h-3.5 text-[#D0A73B]" />
                    <div className="text-right">
                      <span className="text-[10px] font-bold text-[#7E611D] block leading-tight">Tratamento Escolhido:</span>
                      <span className="text-xs font-black text-[#23372B]">{selectedService.name}</span>
                    </div>
                  </div>
                )}
              </div>

              {submitError && (
                <div className="mb-4 p-3.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs flex items-center space-x-2 animate-shake">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span className="font-semibold">{submitError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                {/* Nome Completo */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-[#294232] uppercase tracking-wider mb-1">
                    Nome Completo do Paciente *
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                    <input
                      id="input-patient-name"
                      type="text"
                      required
                      placeholder="Ex: Maria Silva Oliveira"
                      value={patientName}
                      onChange={(e) => setPatientName(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-[#C9D8CB] focus:ring-2 focus:ring-[#5F6D33] text-sm text-slate-800 font-bold bg-[#FDFBF7]"
                    />
                  </div>
                </div>

                {/* Data de Nascimento */}
                <div>
                  <label className="block text-xs font-bold text-[#294232] uppercase tracking-wider mb-1 flex items-center justify-between">
                    <span>Data de Nascimento *</span>
                    <span className="text-[10px] font-bold text-amber-800 bg-amber-100/90 px-2 py-0.5 rounded-full">
                      🎂 Mimo de Aniversário
                    </span>
                  </label>
                  <div className="relative">
                    <Cake className="w-4 h-4 absolute left-3.5 top-3.5 text-amber-600" />
                    <input
                      id="input-patient-birthdate"
                      type="date"
                      required
                      max={todayStr}
                      value={patientBirthDate}
                      onChange={(e) => setPatientBirthDate(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-[#D0A73B]/80 focus:ring-2 focus:ring-[#5F6D33] text-sm text-slate-800 font-bold bg-white"
                    />
                  </div>
                  <p className="text-[10px] text-amber-900 mt-1 font-medium leading-tight">
                    🎂 Enviamos felicitações e mimos de aniversário pelo WhatsApp!
                  </p>
                </div>

                {/* WhatsApp */}
                <div>
                  <label className="block text-xs font-bold text-[#294232] uppercase tracking-wider mb-1 flex items-center justify-between">
                    <span>WhatsApp / Celular com DDD *</span>
                    <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/90 px-2 py-0.5 rounded-full">
                      🔔 Lembrete 2h
                    </span>
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 absolute left-3.5 top-3.5 text-emerald-600" />
                    <input
                      id="input-patient-phone"
                      type="tel"
                      required
                      placeholder="(93) 99999-9999"
                      value={patientPhone}
                      onChange={(e) => setPatientPhone(formatPhoneMask(e.target.value))}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-emerald-300 focus:ring-2 focus:ring-emerald-500 text-sm text-slate-800 font-bold bg-white"
                    />
                  </div>
                  <p className="text-[10px] text-emerald-900 mt-1 font-medium leading-tight">
                    🔔 Enviamos a confirmação e lembretes com <strong>2 horas de antecedência</strong>!
                  </p>
                </div>

                {/* Endereço Completo */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-[#294232] uppercase tracking-wider mb-1">
                    Endereço Completo (Rua, Número e Bairro) *
                  </label>
                  <div className="relative">
                    <Home className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                    <input
                      id="input-patient-address"
                      type="text"
                      required
                      placeholder="Ex: Av. Tancredo Neves, 1234, Bairro Centro"
                      value={patientAddress}
                      onChange={(e) => setPatientAddress(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-[#C9D8CB] focus:ring-2 focus:ring-[#5F6D33] text-sm text-slate-800 font-medium bg-white"
                    />
                  </div>
                </div>

                {/* Cidade / UF */}
                <div>
                  <label className="block text-xs font-bold text-[#294232] uppercase tracking-wider mb-1">
                    Cidade / UF
                  </label>
                  <div className="relative">
                    <Building className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
                    <input
                      id="input-patient-city"
                      type="text"
                      placeholder="Altamira - PA"
                      value={patientCity}
                      onChange={(e) => setPatientCity(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-[#C9D8CB] focus:ring-2 focus:ring-[#5F6D33] text-sm text-slate-800 font-medium bg-white"
                    />
                  </div>
                </div>

                {/* E-mail */}
                <div>
                  <label className="block text-xs font-bold text-[#294232] uppercase tracking-wider mb-1">
                    E-mail (Opcional)
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
                    <input
                      id="input-patient-email"
                      type="email"
                      placeholder="exemplo@email.com"
                      value={patientEmail}
                      onChange={(e) => setPatientEmail(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-[#C9D8CB] focus:ring-2 focus:ring-[#5F6D33] text-sm text-slate-800 font-medium bg-white"
                    />
                  </div>
                </div>

                {/* CPF */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-[#294232] uppercase tracking-wider mb-1">
                    CPF (Opcional - para Recibos e Declaração de IRPF)
                  </label>
                  <div className="relative">
                    <FileText className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
                    <input
                      id="input-patient-cpf"
                      type="text"
                      placeholder="000.000.000-00"
                      value={patientCpf}
                      onChange={(e) => setPatientCpf(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-[#C9D8CB] focus:ring-2 focus:ring-[#5F6D33] text-sm text-slate-800 font-medium bg-white"
                    />
                  </div>
                </div>

                {/* Observações / Queixa */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-[#294232] uppercase tracking-wider mb-1">
                    Observações / Queixa Principal / Histórico de Dores (Opcional)
                  </label>
                  <textarea
                    id="input-patient-notes-reg"
                    rows={2}
                    placeholder="Ex: Dores na lombar ao ficar sentado, indicação médica para fortalecimento..."
                    value={patientNotes}
                    onChange={(e) => setPatientNotes(e.target.value)}
                    className="w-full p-3 rounded-xl border border-[#C9D8CB] focus:ring-2 focus:ring-[#5F6D33] text-sm text-slate-800 bg-white"
                  />
                </div>
              </div>
            </div>

            {/* SEÇÃO 2: SERVIÇO / TRATAMENTO */}
            <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-sm border border-[#C9D8CB]">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                <label htmlFor="select-booking-service" className="text-xs font-extrabold text-[#23372B] uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-[#D0A73B]" />
                  <span>2. Escolha o Serviço / Tratamento *</span>
                </label>
                {onNavigateToServices && (
                  <button
                    type="button"
                    onClick={onNavigateToServices}
                    className="text-xs font-bold text-[#5F6D33] hover:text-[#23372B] hover:underline flex items-center gap-1 self-start sm:self-auto cursor-pointer"
                  >
                    <span>Ver tabela completa de serviços</span>
                    <ExternalLink className="w-3 h-3 text-[#D0A73B]" />
                  </button>
                )}
              </div>

              <select
                id="select-booking-service"
                value={selectedService?.id || ''}
                onChange={(e) => {
                  const s = activeServices.find((srv) => srv.id === e.target.value);
                  if (s) {
                    setSelectedService(s);
                    applyServiceFrequencyDefaults(s);
                  }
                }}
                className="w-full px-4 py-3 rounded-xl border border-[#C9D8CB] bg-white text-[#23372B] font-bold text-sm focus:ring-2 focus:ring-[#5F6D33] focus:border-[#5F6D33] shadow-2xs cursor-pointer"
              >
                {activeServices.map((srv) => (
                  <option key={srv.id} value={srv.id}>
                    {srv.name} — ({srv.durationMinutes} min) — Sob Avaliação
                  </option>
                ))}
              </select>

              {selectedService && (
                <div className="mt-3 p-3 bg-[#F4F7F4] rounded-xl flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex items-center space-x-2">
                    <span className="px-2.5 py-0.5 text-[10px] font-extrabold rounded-md uppercase tracking-wider bg-[#F5EED3] text-[#7E611D] border border-[#D0A73B]/30">
                      {selectedService.category}
                    </span>
                    <span className="text-slate-600 font-medium flex items-center space-x-1">
                      <Clock className="w-3 h-3 text-[#5F6D33]" />
                      <span>{selectedService.durationMinutes} min por atendimento</span>
                    </span>
                  </div>
                  <div className="flex items-center space-x-1.5 font-bold">
                    <span className="text-slate-500 text-[11px]">Condições do Plano:</span>
                    <span className="text-xs font-extrabold text-[#31523D] bg-white px-2.5 py-1 rounded-lg border border-[#C9D8CB]">
                      Definido na Avaliação (CREFITO-PA)
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* SEÇÃO 3: DIAS E HORÁRIOS DO TRATAMENTO (MULTI-DAY / PLANOS) */}
            <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-sm border border-[#C9D8CB] space-y-6">
              <div>
                <div className="flex items-center space-x-2.5">
                  <span className="w-8 h-8 rounded-xl bg-[#31523D] text-[#D0A73B] flex items-center justify-center font-bold text-sm shadow-xs">
                    <CalendarIcon className="w-4 h-4" />
                  </span>
                  <div>
                    <h3 className="text-base sm:text-lg font-serif font-extrabold text-[#23372B] leading-tight">
                      3. Escolha a Frequência, Dias e Horários do Tratamento
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Configure os dias da semana (ex: 2x ou 3x na semana) ou escolha datas específicas
                    </p>
                  </div>
                </div>
              </div>

              {/* Frequência Selector Tabs */}
              <div>
                <label className="block text-xs font-bold text-[#294232] uppercase tracking-wider mb-2">
                  Tipo de Frequência do Plano / Atendimento:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                  
                  {/* Option: 2x na semana */}
                  <button
                    type="button"
                    onClick={() => {
                      setFrequencyType('2x_semana');
                      setDay1Weekday(2); // Terça
                      setDay2Weekday(4); // Quinta
                    }}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                      frequencyType === '2x_semana'
                        ? 'bg-[#F5EED3] border-[#D0A73B] ring-2 ring-[#D0A73B]/50 shadow-xs'
                        : 'bg-white border-[#C9D8CB] hover:border-[#5F6D33] hover:bg-[#F4F7F4]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-black text-[#23372B] flex items-center gap-1.5">
                        <span>🧘 2x na semana</span>
                      </span>
                      {frequencyType === '2x_semana' && (
                        <CheckCircle2 className="w-4 h-4 text-[#7E611D]" />
                      )}
                    </div>
                    <span className="text-[10px] text-slate-600 leading-tight">
                      2 dias fixos/semana (Ideal p/ Pilates 8 sessões e Fisioterapia)
                    </span>
                  </button>

                  {/* Option: 3x na semana */}
                  <button
                    type="button"
                    onClick={() => {
                      setFrequencyType('3x_semana');
                      setDay1Weekday(1); // Seg
                      setDay2Weekday(3); // Qua
                      setDay3Weekday(5); // Sex
                    }}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                      frequencyType === '3x_semana'
                        ? 'bg-[#F5EED3] border-[#D0A73B] ring-2 ring-[#D0A73B]/50 shadow-xs'
                        : 'bg-white border-[#C9D8CB] hover:border-[#5F6D33] hover:bg-[#F4F7F4]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-black text-[#23372B] flex items-center gap-1.5">
                        <span>⚡ 3x na semana</span>
                      </span>
                      {frequencyType === '3x_semana' && (
                        <CheckCircle2 className="w-4 h-4 text-[#7E611D]" />
                      )}
                    </div>
                    <span className="text-[10px] text-slate-600 leading-tight">
                      3 dias fixos/semana (Ideal p/ Pilates 12 sessões e Reabilitação)
                    </span>
                  </button>

                  {/* Option: Múltiplos Dias no Calendário */}
                  <button
                    type="button"
                    onClick={() => setFrequencyType('multiplos_dias')}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                      frequencyType === 'multiplos_dias'
                        ? 'bg-[#F5EED3] border-[#D0A73B] ring-2 ring-[#D0A73B]/50 shadow-xs'
                        : 'bg-white border-[#C9D8CB] hover:border-[#5F6D33] hover:bg-[#F4F7F4]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-black text-[#23372B] flex items-center gap-1.5">
                        <span>📅 Múltiplos Dias</span>
                      </span>
                      {frequencyType === 'multiplos_dias' && (
                        <CheckCircle2 className="w-4 h-4 text-[#7E611D]" />
                      )}
                    </div>
                    <span className="text-[10px] text-slate-600 leading-tight">
                      Marcar várias datas personalizadas no calendário
                    </span>
                  </button>

                  {/* Option: Sessão Única */}
                  <button
                    type="button"
                    onClick={() => setFrequencyType('sessao_unica')}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                      frequencyType === 'sessao_unica'
                        ? 'bg-[#F5EED3] border-[#D0A73B] ring-2 ring-[#D0A73B]/50 shadow-xs'
                        : 'bg-white border-[#C9D8CB] hover:border-[#5F6D33] hover:bg-[#F4F7F4]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-black text-[#23372B] flex items-center gap-1.5">
                        <span>🗓️ Sessão Única</span>
                      </span>
                      {frequencyType === 'sessao_unica' && (
                        <CheckCircle2 className="w-4 h-4 text-[#7E611D]" />
                      )}
                    </div>
                    <span className="text-[10px] text-slate-600 leading-tight">
                      1 dia avulso (Avaliação física ou sessão experimental)
                    </span>
                  </button>
                </div>
              </div>

              {/* VIEW A: WEEKLY PLAN (2x or 3x na semana) */}
              {(frequencyType === '2x_semana' || frequencyType === '3x_semana') && (
                <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-[#FDFBF2] via-[#F5EED3]/30 to-[#EAF0DB]/40 border-2 border-[#D0A73B]/60 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#D0A73B]/30">
                    <div>
                      <h4 className="text-sm font-extrabold text-[#23372B] flex items-center gap-2">
                        <Repeat className="w-4 h-4 text-[#7E611D]" />
                        <span>Configuração dos Dias Fixos da Semana</span>
                      </h4>
                      <p className="text-xs text-[#5F6D33] font-medium">
                        Escolha os dias e os horários que deseja frequentar todas as semanas:
                      </p>
                    </div>

                    {/* Quick Presets */}
                    <div className="flex items-center space-x-1.5 overflow-x-auto">
                      <span className="text-[10px] font-bold text-slate-500 uppercase">Sugestões:</span>
                      {frequencyType === '2x_semana' ? (
                        <>
                          <button
                            type="button"
                            onClick={() => { setDay1Weekday(2); setDay2Weekday(4); }}
                            className="px-2.5 py-1 bg-white hover:bg-[#D0A73B] hover:text-[#23372B] text-slate-700 text-[10px] font-bold rounded-lg border border-[#C9D8CB] transition-all cursor-pointer"
                          >
                            Ter / Qui
                          </button>
                          <button
                            type="button"
                            onClick={() => { setDay1Weekday(1); setDay2Weekday(3); }}
                            className="px-2.5 py-1 bg-white hover:bg-[#D0A73B] hover:text-[#23372B] text-slate-700 text-[10px] font-bold rounded-lg border border-[#C9D8CB] transition-all cursor-pointer"
                          >
                            Seg / Qua
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            type="button"
                            onClick={() => { setDay1Weekday(1); setDay2Weekday(3); setDay3Weekday(5); }}
                            className="px-2.5 py-1 bg-white hover:bg-[#D0A73B] hover:text-[#23372B] text-slate-700 text-[10px] font-bold rounded-lg border border-[#C9D8CB] transition-all cursor-pointer"
                          >
                            Seg / Qua / Sex
                          </button>
                          <button
                            type="button"
                            onClick={() => { setDay1Weekday(2); setDay2Weekday(4); setDay3Weekday(6); }}
                            className="px-2.5 py-1 bg-white hover:bg-[#D0A73B] hover:text-[#23372B] text-slate-700 text-[10px] font-bold rounded-lg border border-[#C9D8CB] transition-all cursor-pointer"
                          >
                            Ter / Qui / Sáb
                          </button>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Day Slots Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
                    {/* Day 1 */}
                    <div className="bg-white p-3.5 rounded-xl border border-[#C9D8CB] space-y-2 shadow-2xs">
                      <span className="text-xs font-black text-[#31523D] flex items-center space-x-1.5">
                        <span className="w-5 h-5 rounded-full bg-[#31523D] text-[#D0A73B] flex items-center justify-center text-[10px] font-black">
                          1
                        </span>
                        <span>1º Dia da Semana</span>
                      </span>

                      <div>
                        <label className="text-[11px] font-bold text-slate-600 block mb-1">Dia:</label>
                        <select
                          value={day1Weekday}
                          onChange={(e) => setDay1Weekday(Number(e.target.value))}
                          className="w-full px-2.5 py-2 rounded-lg border border-[#C9D8CB] bg-white text-xs font-bold text-[#23372B] focus:ring-2 focus:ring-[#5F6D33]"
                        >
                          {WEEKDAY_NAMES.map((w) => (
                            <option key={w.day} value={w.day}>
                              {w.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-slate-600 block mb-1">Horário:</label>
                        <select
                          value={day1Time}
                          onChange={(e) => setDay1Time(e.target.value)}
                          className="w-full px-2.5 py-2 rounded-lg border border-[#C9D8CB] bg-white text-xs font-bold text-[#23372B] focus:ring-2 focus:ring-[#5F6D33]"
                        >
                          {STANDARD_TIMES.map((t) => (
                            <option key={t} value={t}>
                              {t} hs
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Day 2 */}
                    <div className="bg-white p-3.5 rounded-xl border border-[#C9D8CB] space-y-2 shadow-2xs">
                      <span className="text-xs font-black text-[#31523D] flex items-center space-x-1.5">
                        <span className="w-5 h-5 rounded-full bg-[#31523D] text-[#D0A73B] flex items-center justify-center text-[10px] font-black">
                          2
                        </span>
                        <span>2º Dia da Semana</span>
                      </span>

                      <div>
                        <label className="text-[11px] font-bold text-slate-600 block mb-1">Dia:</label>
                        <select
                          value={day2Weekday}
                          onChange={(e) => setDay2Weekday(Number(e.target.value))}
                          className="w-full px-2.5 py-2 rounded-lg border border-[#C9D8CB] bg-white text-xs font-bold text-[#23372B] focus:ring-2 focus:ring-[#5F6D33]"
                        >
                          {WEEKDAY_NAMES.map((w) => (
                            <option key={w.day} value={w.day}>
                              {w.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-slate-600 block mb-1">Horário:</label>
                        <select
                          value={day2Time}
                          onChange={(e) => setDay2Time(e.target.value)}
                          className="w-full px-2.5 py-2 rounded-lg border border-[#C9D8CB] bg-white text-xs font-bold text-[#23372B] focus:ring-2 focus:ring-[#5F6D33]"
                        >
                          {STANDARD_TIMES.map((t) => (
                            <option key={t} value={t}>
                              {t} hs
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Day 3 (if 3x/week) */}
                    {frequencyType === '3x_semana' && (
                      <div className="bg-white p-3.5 rounded-xl border border-[#C9D8CB] space-y-2 shadow-2xs">
                        <span className="text-xs font-black text-[#31523D] flex items-center space-x-1.5">
                          <span className="w-5 h-5 rounded-full bg-[#31523D] text-[#D0A73B] flex items-center justify-center text-[10px] font-black">
                            3
                          </span>
                          <span>3º Dia da Semana</span>
                        </span>

                        <div>
                          <label className="text-[11px] font-bold text-slate-600 block mb-1">Dia:</label>
                          <select
                            value={day3Weekday}
                            onChange={(e) => setDay3Weekday(Number(e.target.value))}
                            className="w-full px-2.5 py-2 rounded-lg border border-[#C9D8CB] bg-white text-xs font-bold text-[#23372B] focus:ring-2 focus:ring-[#5F6D33]"
                          >
                            {WEEKDAY_NAMES.map((w) => (
                              <option key={w.day} value={w.day}>
                                {w.name}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="text-[11px] font-bold text-slate-600 block mb-1">Horário:</label>
                          <select
                            value={day3Time}
                            onChange={(e) => setDay3Time(e.target.value)}
                            className="w-full px-2.5 py-2 rounded-lg border border-[#C9D8CB] bg-white text-xs font-bold text-[#23372B] focus:ring-2 focus:ring-[#5F6D33]"
                          >
                            {STANDARD_TIMES.map((t) => (
                              <option key={t} value={t}>
                                {t} hs
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Start Date of Plan */}
                  <div className="pt-3 border-t border-[#D0A73B]/30 space-y-2">
                    <label className="block text-xs font-bold text-[#294232] uppercase tracking-wider">
                      Data de Início do Plano (Primeira Sessão):
                    </label>
                    <div className="flex flex-wrap items-center gap-2.5">
                      <input
                        type="date"
                        min={todayStr}
                        max={maxDateStr}
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                        className="px-3.5 py-2.5 rounded-xl border border-[#C9D8CB] bg-white text-sm font-bold text-[#23372B] focus:ring-2 focus:ring-[#5F6D33]"
                      />
                      <span className="text-xs text-slate-600 font-medium">
                        (Início a partir de: <strong>{formatDatePtBR(selectedDate)}</strong>)
                      </span>
                    </div>
                  </div>

                  {/* Live Summary Callout */}
                  <div className="p-3 bg-white rounded-xl border border-[#D0A73B] text-xs font-bold text-[#23372B] flex items-center space-x-2">
                    <CheckSquare className="w-4 h-4 text-[#5F6D33] shrink-0" />
                    <span>
                      Programação Selecionada: <strong className="text-[#31523D]">{currentScheduleData.planScheduleSummary}</strong>
                    </span>
                  </div>
                </div>
              )}

              {/* VIEW B: CUSTOM MULTI-DATES CALENDAR (Escolher Várias Datas Específicas) */}
              {frequencyType === 'multiplos_dias' && (
                <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-[#FDFBF2] via-[#F5EED3]/30 to-[#EAF0DB]/40 border-2 border-[#D0A73B]/60 space-y-4">
                  <div>
                    <h4 className="text-sm font-extrabold text-[#23372B] flex items-center gap-2">
                      <CalendarIcon className="w-4 h-4 text-[#7E611D]" />
                      <span>Selecione as Datas das Sessões no Calendário</span>
                    </h4>
                    <p className="text-xs text-[#5F6D33] font-medium mt-0.5">
                      Clique nos dias abaixo para adicionar à sua lista de sessões de Fisioterapia/Pilates:
                    </p>
                  </div>

                  {/* Quick Date Chips for adding/removing */}
                  <div className="overflow-x-auto pb-2 scrollbar-thin">
                    <div className="flex items-center space-x-2 min-w-max">
                      {getQuickDateOptions().map((opt) => {
                        const isAdded = customMultiDates.some((d) => d.date === opt.dateStr);
                        return (
                          <button
                            key={opt.dateStr}
                            type="button"
                            disabled={opt.isSunday}
                            onClick={() => {
                              if (isAdded) {
                                setCustomMultiDates(customMultiDates.filter((d) => d.date !== opt.dateStr));
                              } else {
                                handleAddCustomDate(opt.dateStr);
                              }
                            }}
                            className={`p-2.5 rounded-2xl border text-center transition-all flex flex-col items-center justify-between min-w-[72px] h-[78px] cursor-pointer ${
                              opt.isSunday
                                ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed opacity-60'
                                : isAdded
                                ? 'bg-[#31523D] text-white border-[#31523D] shadow-md ring-2 ring-[#D0A73B] scale-105'
                                : 'bg-white text-[#23372B] border-[#C9D8CB] hover:border-[#5F6D33] hover:bg-[#EAF0DB]/50'
                            }`}
                          >
                            <span className={`text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded-full ${
                              isAdded ? 'bg-[#D0A73B] text-[#23372B]' : 'bg-[#EAF0DB] text-[#5F6D33]'
                            }`}>
                              {isAdded ? '✓ ADD' : opt.badge}
                            </span>
                            <div className="my-0.5">
                              <span className="text-base font-black block leading-none">{opt.dayNum}</span>
                              <span className="text-[10px] opacity-75 block leading-tight">{opt.monthNum}</span>
                            </div>
                            {opt.isSunday && <span className="text-[9px] font-bold text-slate-400">Fechado</span>}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Manual Date Input Picker */}
                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-[#D0A73B]/30">
                    <label className="text-xs font-bold text-slate-700">Adicionar outra data:</label>
                    <input
                      type="date"
                      min={todayStr}
                      max={maxDateStr}
                      value={selectedDate}
                      onChange={(e) => setSelectedDate(e.target.value)}
                      className="px-3 py-1.5 rounded-xl border border-[#C9D8CB] bg-white text-xs font-bold text-[#23372B]"
                    />
                    <button
                      type="button"
                      onClick={() => handleAddCustomDate(selectedDate)}
                      className="px-3 py-1.5 bg-[#31523D] hover:bg-[#23372B] text-[#F5EED3] rounded-xl text-xs font-bold flex items-center space-x-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Adicionar Data</span>
                    </button>
                  </div>

                  {/* Selected Dates List & Times */}
                  <div className="space-y-2 pt-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-[#23372B] uppercase">
                        Sessões Selecionadas ({customMultiDates.length} datas):
                      </span>
                      {customMultiDates.length > 0 && (
                        <span className="text-[11px] text-[#5F6D33] font-bold">
                          Configure o horário de cada sessão:
                        </span>
                      )}
                    </div>

                    {customMultiDates.length === 0 ? (
                      <p className="text-xs text-amber-800 bg-amber-50 p-3 rounded-xl border border-amber-200">
                        Nenhuma data selecionada ainda. Clique nos dias acima para agendar suas sessões!
                      </p>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {customMultiDates.map((item, idx) => (
                          <div
                            key={item.date}
                            className="bg-white p-3 rounded-xl border border-[#C9D8CB] flex items-center justify-between gap-2 shadow-2xs"
                          >
                            <div className="flex items-center space-x-2">
                              <span className="w-6 h-6 rounded-full bg-[#EAF0DB] text-[#31523D] flex items-center justify-center text-xs font-black">
                                {idx + 1}
                              </span>
                              <div>
                                <span className="text-xs font-extrabold text-[#23372B] block">
                                  {formatDatePtBR(item.date)}
                                </span>
                              </div>
                            </div>

                            <div className="flex items-center space-x-2">
                              <select
                                value={item.time}
                                onChange={(e) => handleUpdateCustomDateTime(idx, e.target.value)}
                                className="px-2 py-1 rounded-lg border border-[#C9D8CB] text-xs font-bold bg-[#F4F7F4] text-[#23372B]"
                              >
                                {STANDARD_TIMES.map((t) => (
                                  <option key={t} value={t}>
                                    {t} hs
                                  </option>
                                ))}
                              </select>

                              <button
                                type="button"
                                onClick={() => handleRemoveCustomDate(idx)}
                                className="text-rose-500 hover:text-rose-700 p-1 hover:bg-rose-50 rounded-lg cursor-pointer"
                                title="Remover data"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* VIEW C: SINGLE SESSION (Sessão Única / Avaliação) */}
              {frequencyType === 'sessao_unica' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-bold text-[#294232] uppercase tracking-wider">
                      Data da Sessão Única:
                    </label>
                    <span className="text-[11px] text-[#5F6D33] font-semibold">
                      Data: <strong className="text-[#31523D]">{formatDatePtBR(selectedDate)}</strong>
                    </span>
                  </div>

                  {/* Horizontal Scrollable Quick Date Chips */}
                  <div className="overflow-x-auto pb-2 scrollbar-thin">
                    <div className="flex items-center space-x-2 min-w-max">
                      {getQuickDateOptions().map((opt) => {
                        const isSelected = selectedDate === opt.dateStr;
                        return (
                          <button
                            key={opt.dateStr}
                            type="button"
                            onClick={() => setSelectedDate(opt.dateStr)}
                            disabled={opt.isSunday}
                            className={`p-2.5 rounded-2xl border text-center transition-all flex flex-col items-center justify-between min-w-[72px] h-[78px] cursor-pointer ${
                              opt.isSunday
                                ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed opacity-60'
                                : isSelected
                                ? 'bg-[#31523D] text-white border-[#31523D] shadow-md ring-2 ring-[#D0A73B] scale-105'
                                : 'bg-white text-[#23372B] border-[#C9D8CB] hover:border-[#5F6D33] hover:bg-[#EAF0DB]/50'
                            }`}
                          >
                            <span className={`text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded-full ${
                              isSelected ? 'bg-[#D0A73B] text-[#23372B]' : 'bg-[#EAF0DB] text-[#5F6D33]'
                            }`}>
                              {opt.badge}
                            </span>
                            <div className="my-0.5">
                              <span className="text-base font-black block leading-none">{opt.dayNum}</span>
                              <span className="text-[10px] opacity-75 block leading-tight">{opt.monthNum}</span>
                            </div>
                            {opt.isSunday && <span className="text-[9px] font-bold text-slate-400">Fechado</span>}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Date Input Selector */}
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="relative max-w-xs flex-1">
                      <input
                        id="input-booking-date"
                        type="date"
                        min={todayStr}
                        max={maxDateStr}
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl border border-[#C9D8CB] focus:ring-2 focus:ring-[#5F6D33] text-slate-800 font-bold text-sm bg-[#F4F7F4]"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={handleJumpToNextAvailableDate}
                      className="px-3.5 py-2.5 rounded-xl bg-[#EAF0DB] hover:bg-[#C9D8CB] text-[#31523D] border border-[#9CB55E]/50 text-xs font-extrabold transition-all flex items-center space-x-1.5 cursor-pointer"
                    >
                      <CalendarIcon className="w-3.5 h-3.5 text-[#5F6D33]" />
                      <span>Próximo Dia Útil →</span>
                    </button>
                  </div>

                  {/* Available Slot Grid */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-xs font-bold text-[#294232] uppercase tracking-wider">
                        Horários Disponíveis ({formatDatePtBR(selectedDate)})
                      </label>
                      <span className="text-[11px] text-[#5F6D33] font-semibold">
                        Horário escolhido: <strong>{selectedTime} hs</strong>
                      </span>
                    </div>

                    {slotsLoading ? (
                      <div className="py-8 text-center text-slate-500 text-sm flex items-center justify-center space-x-2">
                        <RefreshCw className="w-4 h-4 animate-spin text-[#5F6D33]" />
                        <span>Verificando horários na agenda...</span>
                      </div>
                    ) : slotError || availableSlots.length === 0 ? (
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                        {STANDARD_TIMES.map((t) => {
                          const isSelected = selectedTime === t;
                          return (
                            <button
                              key={t}
                              type="button"
                              onClick={() => setSelectedTime(t)}
                              className={`p-3 rounded-2xl text-xs font-extrabold border transition-all cursor-pointer ${
                                isSelected
                                  ? 'bg-[#31523D] text-white border-[#31523D] ring-2 ring-[#D0A73B]'
                                  : 'bg-white text-[#23372B] border-[#C9D8CB] hover:bg-[#EAF0DB]'
                              }`}
                            >
                              <span>{t} hs</span>
                            </button>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                        {availableSlots.map((slot) => {
                          const isSelected = selectedTime === slot.time;
                          return (
                            <button
                              key={slot.time}
                              type="button"
                              onClick={() => {
                                if (slot.available) {
                                  setSelectedTime(slot.time);
                                } else {
                                  setSelectedBlockedSlot(slot);
                                }
                              }}
                              className={`p-3 rounded-2xl text-xs transition-all border flex flex-col items-center justify-center space-y-1 relative cursor-pointer ${
                                !slot.available
                                  ? 'bg-slate-50 text-slate-400 border-slate-200 opacity-70'
                                  : isSelected
                                  ? 'bg-[#31523D] text-white border-[#31523D] shadow-md ring-2 ring-[#D0A73B]'
                                  : 'bg-white text-[#23372B] border-[#C9D8CB] hover:border-[#5F6D33] hover:bg-[#EAF0DB]/60'
                              }`}
                            >
                              <span className="text-sm font-extrabold">{slot.time} hs</span>
                              <span className="text-[10px] font-bold opacity-80">
                                {slot.available ? (slot.statusLabel || '🟢 Vagas Livres') : '🔒 Lotado'}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Bottom CTA to Proceed to Review & Payment */}
            <div className="bg-white rounded-2xl p-5 border border-[#C9D8CB] shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-center sm:text-left">
                <span className="text-xs text-slate-500 font-bold uppercase block">Resumo do Agendamento:</span>
                <p className="text-sm font-extrabold text-[#23372B]">
                  {selectedService?.name} • {currentScheduleData.planScheduleSummary}
                </p>
              </div>

              <button
                id="btn-step1-next"
                type="button"
                onClick={handleNextStep}
                className="w-full sm:w-auto px-8 py-3.5 rounded-xl font-extrabold text-sm bg-[#31523D] hover:bg-[#23372B] text-white shadow-md flex items-center justify-center space-x-2 transition-all cursor-pointer ring-2 ring-[#D0A73B]/50"
              >
                <span>Avançar para Revisão & Pagamento</span>
                <ChevronRight className="w-4 h-4 text-[#D0A73B]" />
              </button>
            </div>

          </div>
        )}

        {/* STEP 2: REVIEW & PAYMENT METHOD SELECTION */}
        {step === 2 && (
          <form onSubmit={handleSubmitBooking} className="bg-white rounded-2xl p-5 sm:p-6 shadow-sm border border-[#C9D8CB]">
            <h3 className="text-lg font-bold text-[#23372B] mb-1">
              Revisão do Atendimento & Forma de Pagamento
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mb-5">
              Confira seus dados cadastrais, a programação dos atendimentos e selecione a forma de pagamento.
            </p>

            {/* Comprehensive Booking Summary Card */}
            <div className="bg-[#F4F7F4] border-2 border-[#D0A73B]/70 rounded-2xl p-5 mb-6 space-y-3 text-xs text-[#23372B] shadow-2xs">
              <div className="flex justify-between items-center font-bold text-sm text-[#31523D] pb-2 border-b border-[#C9D8CB]">
                <div className="flex items-center space-x-2">
                  <Sparkles className="w-4 h-4 text-[#D0A73B]" />
                  <span>{selectedService?.name}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-extrabold text-[#5F6D33] bg-[#EAF0DB] px-2.5 py-1 rounded-full uppercase tracking-wider border border-[#9CB55E]/40">
                    Sob Avaliação Fisioterapêutica
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-slate-500 block">Paciente Cadastrado:</span>
                  <strong className="text-slate-900">{patientName}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block">WhatsApp:</span>
                  <strong className="text-emerald-700">{patientPhone}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block">Data de Nascimento:</span>
                  <strong className="text-amber-800">{formatDatePtBR(patientBirthDate)}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block">Endereço:</span>
                  <strong className="text-slate-800">{patientAddress} ({patientCity})</strong>
                </div>
              </div>

              <div className="pt-2 border-t border-[#C9D8CB] text-xs">
                <span className="text-slate-500 block">Programação / Dias Escolhidos:</span>
                <strong className="text-[#31523D] font-extrabold">
                  {currentScheduleData.planScheduleSummary}
                </strong>
              </div>
            </div>

            {submitError && (
              <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-xl text-xs flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{submitError}</span>
              </div>
            )}

            {/* Payment Methods Selection */}
            <div className="space-y-4">
              <label className="block text-xs font-bold text-[#294232] uppercase tracking-wider">
                Escolha a Forma de Pagamento *
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                {/* Option 1: PIX */}
                <div
                  onClick={() => setPaymentMethod('pix')}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all flex flex-col justify-between ${
                    paymentMethod === 'pix'
                      ? 'bg-[#F5EED3]/80 border-[#D0A73B] shadow-2xs ring-2 ring-[#D0A73B]/40'
                      : 'bg-white border-[#C9D8CB] hover:border-[#5F6D33]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="p-1.5 rounded-lg bg-[#31523D] text-[#F5EED3]">
                      <QrCode className="w-4 h-4" />
                    </span>
                    <span className={`w-4 h-4 rounded-full border flex items-center justify-center text-[10px] font-bold ${
                      paymentMethod === 'pix' ? 'bg-[#31523D] text-[#D0A73B] border-[#31523D]' : 'border-slate-300'
                    }`}>
                      {paymentMethod === 'pix' && '✓'}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#23372B]">PIX Instantâneo</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">Chave Celular/E-mail</p>
                  </div>
                </div>

                {/* Option 2: Cartão Recorrente */}
                <div
                  onClick={() => setPaymentMethod('cartao_recorrente')}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all flex flex-col justify-between relative overflow-hidden ${
                    paymentMethod === 'cartao_recorrente'
                      ? 'bg-[#F5EED3] border-[#D0A73B] shadow-sm ring-2 ring-[#D0A73B]/60'
                      : 'bg-[#FDFBF5] border-[#D0A73B]/50 hover:border-[#D0A73B]'
                  }`}
                >
                  <span className="absolute top-0 right-0 bg-[#31523D] text-[#D0A73B] text-[9px] font-black px-2 py-0.5 rounded-bl-lg uppercase tracking-wider">
                    Não compromete o limite!
                  </span>
                  <div className="flex items-center justify-between mb-2 mt-1">
                    <span className="p-1.5 rounded-lg bg-[#31523D] text-[#D0A73B]">
                      <CreditCard className="w-4 h-4" />
                    </span>
                    <span className={`w-4 h-4 rounded-full border flex items-center justify-center text-[10px] font-bold ${
                      paymentMethod === 'cartao_recorrente' ? 'bg-[#31523D] text-[#D0A73B] border-[#31523D]' : 'border-slate-300'
                    }`}>
                      {paymentMethod === 'cartao_recorrente' && '✓'}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-xs font-extrabold text-[#23372B]">Cartão Recorrente</h4>
                    <p className="text-[10px] text-amber-800 font-bold mt-0.5">Desconta só 1 parcela por mês!</p>
                  </div>
                </div>

                {/* Option 3: Link de Cartão */}
                <div
                  onClick={() => setPaymentMethod('card_link')}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all flex flex-col justify-between ${
                    paymentMethod === 'card_link'
                      ? 'bg-[#F5EED3]/80 border-[#D0A73B] shadow-2xs ring-2 ring-[#D0A73B]/40'
                      : 'bg-white border-[#C9D8CB] hover:border-[#5F6D33]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="p-1.5 rounded-lg bg-[#31523D] text-[#F5EED3]">
                      <CreditCard className="w-4 h-4" />
                    </span>
                    <span className={`w-4 h-4 rounded-full border flex items-center justify-center text-[10px] font-bold ${
                      paymentMethod === 'card_link' ? 'bg-[#31523D] text-[#D0A73B] border-[#31523D]' : 'border-slate-300'
                    }`}>
                      {paymentMethod === 'card_link' && '✓'}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#23372B]">Link de Cartão</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">Crédito ou Débito em até 12x</p>
                  </div>
                </div>

                {/* Option 4: Presencial */}
                <div
                  onClick={() => setPaymentMethod('presencial')}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all flex flex-col justify-between ${
                    paymentMethod === 'presencial'
                      ? 'bg-[#F5EED3]/80 border-[#D0A73B] shadow-2xs ring-2 ring-[#D0A73B]/40'
                      : 'bg-white border-[#C9D8CB] hover:border-[#5F6D33]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="p-1.5 rounded-lg bg-[#31523D] text-[#F5EED3]">
                      <User className="w-4 h-4" />
                    </span>
                    <span className={`w-4 h-4 rounded-full border flex items-center justify-center text-[10px] font-bold ${
                      paymentMethod === 'presencial' ? 'bg-[#31523D] text-[#D0A73B] border-[#31523D]' : 'border-slate-300'
                    }`}>
                      {paymentMethod === 'presencial' && '✓'}
                    </span>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#23372B]">Pagar na Clínica</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">Na recepção no atendimento</p>
                  </div>
                </div>
              </div>

              {/* Dynamic Payment Details Banner */}
              {paymentMethod === 'pix' && (
                <div className="p-3.5 bg-[#F4F7F4] rounded-xl border border-[#C9D8CB] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                  <div>
                    <span className="text-[11px] font-bold text-[#31523D] uppercase tracking-wide block">Chave PIX da Clínica:</span>
                    <p className="text-sm font-extrabold text-[#23372B]">93991265006 <span className="text-xs font-normal text-slate-500">(Dra. Elays Marinho)</span></p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText('93991265006');
                      setCopiedPix(true);
                      setTimeout(() => setCopiedPix(false), 2500);
                    }}
                    className="px-3.5 py-1.5 bg-[#23372B] hover:bg-[#31523D] text-[#F5EED3] text-xs font-bold rounded-lg flex items-center space-x-1.5 shrink-0 transition-all cursor-pointer"
                  >
                    {copiedPix ? <Check className="w-3.5 h-3.5 text-[#D0A73B]" /> : <Copy className="w-3.5 h-3.5 text-[#D0A73B]" />}
                    <span>{copiedPix ? 'Chave Copiada!' : 'Copiar Chave PIX'}</span>
                  </button>
                </div>
              )}

              {paymentMethod === 'cartao_recorrente' && (
                <div className="p-4 bg-gradient-to-r from-[#F5EED3] via-white to-[#EAF0DB] rounded-xl border-2 border-[#D0A73B] shadow-2xs space-y-1.5">
                  <div className="flex items-center space-x-2 text-[#31523D]">
                    <CreditCard className="w-4 h-4 text-[#D0A73B]" />
                    <span className="text-xs font-black uppercase tracking-wide">
                      Vantagem Exclusiva: Não compromete o limite do seu cartão!
                    </span>
                  </div>
                  <p className="text-xs text-[#23372B] font-semibold leading-relaxed">
                    No <strong>Cartão Recorrente</strong>, é debitado na sua fatura <strong>apenas o valor de uma mensalidade por mês</strong>. O limite total do seu cartão NÃO é bloqueado ou comprometido, garantindo total liberdade e sem surpresas!
                  </p>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="mt-8 pt-4 border-t border-[#E4EBE4] flex items-center justify-between">
              <button
                type="button"
                onClick={handlePrevStep}
                className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 flex items-center space-x-1 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Voltar e Ajustar Cadastro/Dias</span>
              </button>

              <button
                id="btn-submit-booking"
                type="submit"
                disabled={submitting}
                className="px-6 py-3.5 rounded-xl font-bold text-sm bg-[#31523D] hover:bg-[#23372B] active:scale-95 text-white disabled:opacity-50 disabled:cursor-not-allowed shadow-md flex items-center space-x-2 transition-all cursor-pointer ring-2 ring-[#D0A73B]/50"
              >
                {submitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-[#D0A73B]" />
                    <span>Confirmando Agendamento...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-[#D0A73B]" />
                    <span>Garantir Meu Horário & Confirmar</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}

        {/* STEP 3: CONFIRMATION SCREEN */}
        {step === 3 && confirmedAppointment && (
          <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-[#C9D8CB] text-center">
            
            <div className="w-16 h-16 bg-[#F5EED3] text-[#9E7F22] border border-[#D0A73B]/40 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <h3 className="text-2xl font-serif font-extrabold text-[#23372B] tracking-tight">
              Agendamento Solicitado com Sucesso!
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-md mx-auto">
              Seu horário está pré-reservado na agenda do <strong className="text-[#31523D]">{clinic.name}</strong>.
            </p>

            {/* Confirmation Ticket Card */}
            <div className="bg-[#F4F7F4] border border-[#C9D8CB] rounded-2xl p-5 my-6 text-left max-w-md mx-auto shadow-2xs">
              <div className="flex items-center justify-between pb-3 border-b border-[#C9D8CB] mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-[#7E611D]">Comprovante de Pré-Agendamento</span>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#E4EBE4] text-[#31523D] border border-[#769E82]/30">
                  RESERVADO
                </span>
              </div>

              <div className="space-y-2.5 text-xs sm:text-sm text-slate-700">
                <div className="flex justify-between">
                  <span className="text-slate-500">Paciente:</span>
                  <span className="font-bold text-[#23372B]">{confirmedAppointment.patientName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Serviço:</span>
                  <span className="font-bold text-[#31523D]">{confirmedAppointment.serviceName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Programação / Dias:</span>
                  <span className="font-bold text-[#23372B] text-right max-w-[240px]">
                    {confirmedAppointment.planScheduleSummary || `${formatDatePtBR(confirmedAppointment.date)} às ${confirmedAppointment.time} hs`}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Condições / Plano:</span>
                  <span className="font-bold text-[#31523D] text-right">Sob Avaliação Fisioterapêutica (CREFITO-PA)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Forma de Pagamento:</span>
                  <span className="font-bold text-[#31523D]">
                    {confirmedAppointment.paymentMethod === 'pix' 
                      ? 'PIX Instantâneo' 
                      : confirmedAppointment.paymentMethod === 'cartao_recorrente'
                      ? 'Cartão Recorrente'
                      : confirmedAppointment.paymentMethod === 'card_link' 
                      ? 'Link de Cartão' 
                      : 'Presencial na Recepção'}
                  </span>
                </div>
                <div className="flex justify-between items-center pt-1 border-t border-slate-100">
                  <span className="text-slate-500 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-[#5F6D33]" />
                    <span>Endereço:</span>
                  </span>
                  <a
                    href={getClinicMapUrl(clinic.address, clinic.city)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-bold text-[#31523D] hover:text-[#23372B] hover:underline text-right flex items-center space-x-1"
                    title="Abrir no Google Maps"
                  >
                    <span>{clinic.address}</span>
                    <Navigation className="w-3.5 h-3.5 text-[#D0A73B]" />
                  </a>
                </div>
              </div>

              {/* Payment Action Block in Confirmation */}
              {(confirmedAppointment.paymentMethod === 'pix' || paymentMethod === 'pix') && (
                <div className="mt-4 pt-3 border-t border-[#C9D8CB] bg-[#F5EED3]/60 p-3 rounded-xl border border-[#D0A73B]/50">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-[#23372B] flex items-center space-x-1">
                      <QrCode className="w-4 h-4 text-[#31523D]" />
                      <span>Chave PIX da Clínica:</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText('93991265006');
                        setCopiedPix(true);
                        setTimeout(() => setCopiedPix(false), 2500);
                      }}
                      className="px-2.5 py-1 bg-[#31523D] text-[#F5EED3] text-[11px] font-bold rounded-lg hover:bg-[#23372B] transition-all flex items-center space-x-1 cursor-pointer"
                    >
                      {copiedPix ? <Check className="w-3.5 h-3.5 text-[#D0A73B]" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedPix ? 'Copiado!' : 'Copiar Chave'}</span>
                    </button>
                  </div>
                  <p className="text-sm font-extrabold text-[#31523D]">93991265006 <span className="text-xs font-normal text-slate-600">(Celular)</span></p>
                  <p className="text-[11px] text-[#7E611D] mt-1 italic">
                    Realize o PIX e envie o comprovante clicando no botão do WhatsApp abaixo para confirmação imediata.
                  </p>
                </div>
              )}

              {(confirmedAppointment.paymentMethod === 'card_link' || paymentMethod === 'card_link') && (
                <div className="mt-4 pt-3 border-t border-[#C9D8CB] bg-[#F4F7F4] p-3 rounded-xl border border-[#C9D8CB]">
                  <span className="text-xs font-bold text-[#23372B] flex items-center space-x-1 mb-1">
                    <CreditCard className="w-4 h-4 text-[#31523D]" />
                    <span>Link de Pagamento no Cartão:</span>
                  </span>
                  <a
                    href="https://link.mercadopago.com.br/fisiolys"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center space-x-1 text-xs font-bold text-[#31523D] bg-[#F5EED3] border border-[#D0A73B] px-3 py-1.5 rounded-lg hover:bg-[#EBDC9C] transition-all"
                  >
                    <span>Pagar com Cartão (Mercado Pago)</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}

              {/* Webhook notification pill */}
              <div className="mt-4 pt-3 border-t border-[#C9D8CB] text-[11px] flex items-center justify-between text-slate-500">
                <span className="flex items-center space-x-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#5F6D33]" />
                  <span>Notificação da Clínica:</span>
                </span>
                <span className={`font-semibold ${webhookStatus ? 'text-[#31523D]' : 'text-slate-500'}`}>
                  {webhookStatus ? 'Enviada ao Gestor' : 'Registrada no Sistema'}
                </span>
              </div>
            </div>

            {/* Direct WhatsApp Confirmation Button */}
            <div className="space-y-3 max-w-md mx-auto">
              <button
                id="btn-whatsapp-confirm"
                onClick={handleOpenWhatsAppConfirmation}
                className="w-full py-3.5 px-6 rounded-xl font-bold text-sm bg-[#31523D] hover:bg-[#23372B] text-white shadow-md flex items-center justify-center space-x-2 transition-all border border-[#D0A73B]/40 cursor-pointer"
              >
                <Send className="w-4 h-4 text-[#D0A73B]" />
                <span>Enviar Confirmação no WhatsApp da Clínica</span>
              </button>

              <button
                onClick={() => {
                  setStep(1);
                  setSelectedService(null);
                  setSelectedTime('08:00');
                  setConfirmedAppointment(null);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-all cursor-pointer"
              >
                Fazer Outro Agendamento
              </button>
            </div>

          </div>
        )}

        {/* Clube de Fidelidade e Vantagens Fisiolys com Consulta de Saldo e Indique & Ganhe */}
        <LoyaltyProgramSection clinicPhone={clinic.whatsapp || '5593991265006'} />

        {/* App Download QR Code Section */}
        <DownloadAppQRSection clinicName={clinic.name} />

        {/* Patient Testimonials & 5-Star Reviews Section */}
        <TestimonialsSection />

      </div>
    </div>
  );
};
