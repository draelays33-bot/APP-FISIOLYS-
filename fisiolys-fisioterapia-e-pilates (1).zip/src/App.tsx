import React, { useState, useEffect, useCallback } from 'react';
import { AppView, ClinicConfig, Service, ScheduleConfig, Appointment, Patient, LoyaltyMember } from './types';
import { api } from './services/api';
import { Header } from './components/Header';
import { PublicBooking } from './components/public/PublicBooking';
import { ServicesCatalogView } from './components/public/ServicesCatalogView';
import { PatientPortal } from './components/patient/PatientPortal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { GlobalSearchModal } from './components/common/GlobalSearchModal';
import { SettingsModal } from './components/common/SettingsModal';
import { RefreshCw, AlertCircle, Sparkles, Lock, Shield } from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>(() => {
    try {
      if (typeof window !== 'undefined') {
        const urlParams = new URLSearchParams(window.location.search);
        const viewParam = urlParams.get('view');
        const actionParam = urlParams.get('action');
        const tabParam = urlParams.get('tab');
        const checkinParam = urlParams.get('checkin');

        if (actionParam === 'checkin' || tabParam === 'checkin' || checkinParam === 'true') {
          return 'patient_portal';
        }
        if (viewParam === 'admin') {
          return 'admin';
        }
        if (viewParam === 'patient_portal' || viewParam === 'gestao' || viewParam === 'frequencia' || viewParam === 'checkin') {
          return 'patient_portal';
        }
        if (viewParam === 'services' || viewParam === 'servicos' || viewParam === 'tratamentos') {
          return 'services';
        }
        if (viewParam === 'public' || viewParam === 'agendamento') {
          return 'public';
        }
      }
    } catch (e) {
      console.error("Error reading URL parameters", e);
    }
    return 'public';
  });

  const [clinic, setClinic] = useState<ClinicConfig | null>(null);
  const [services, setServices] = useState<Service[]>([]);
  const [schedule, setSchedule] = useState<ScheduleConfig | null>(null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loyaltyMembers, setLoyaltyMembers] = useState<LoyaltyMember[]>([]);
  const [preselectedService, setPreselectedService] = useState<Service | null>(null);
  const [patientPortalInitialTab, setPatientPortalInitialTab] = useState<'frequencia' | 'checkin' | 'extrato' | 'declaracao_ir' | 'fidelidade' | 'proximos'>('frequencia');

  // Search and Settings Modals
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Password Authentication State for Admin Panel
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('fisiolys_admin_auth') === 'true';
    } catch {
      return false;
    }
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Keyboard shortcut for search: Ctrl+K or Cmd+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const loadData = useCallback(async () => {
    try {
      setError(null);
      const [clinicRes, servicesRes, scheduleRes, apptsRes, patientsRes, loyaltyRes] = await Promise.all([
        api.getClinic(),
        api.getServices(),
        api.getScheduleConfig(),
        api.getAppointments(),
        api.getPatients(),
        api.getLoyaltyMembers().catch(() => []),
      ]);

      setClinic(clinicRes);
      setServices(servicesRes);
      setSchedule(scheduleRes);
      setAppointments(apptsRes);
      setPatients(patientsRes);
      setLoyaltyMembers(loyaltyRes);
    } catch (err: any) {
      console.error("Error loading application data:", err);
      setError("Não foi possível carregar os dados da clínica. Verifique se o servidor está ativo.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleAdminLoginSuccess = () => {
    try {
      sessionStorage.setItem('fisiolys_admin_auth', 'true');
    } catch (e) {
      console.error(e);
    }
    setIsAdminAuthenticated(true);
  };

  const handleAdminLogout = () => {
    try {
      sessionStorage.removeItem('fisiolys_admin_auth');
    } catch (e) {
      console.error(e);
    }
    setIsAdminAuthenticated(false);
    setCurrentView('patient_portal');
  };

  const handleViewChange = (view: AppView) => {
    if (view === 'admin' && !isAdminAuthenticated) {
      // The Header component handles opening the password modal
      return;
    }
    setCurrentView(view);
  };

  const handleSearchNavigate = (type: string, item: any) => {
    if (type === 'patient') {
      setPatientPortalInitialTab('frequencia');
      setCurrentView('patient_portal');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (type === 'service') {
      setPreselectedService(item as Service);
      setCurrentView('public');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (type === 'appointment') {
      if (isAdminAuthenticated) {
        setCurrentView('admin');
      } else {
        setPatientPortalInitialTab('proximos');
        setCurrentView('patient_portal');
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (type === 'loyalty') {
      setPatientPortalInitialTab('fidelidade');
      setCurrentView('patient_portal');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F7F8F3] flex flex-col items-center justify-center p-4">
        <div className="w-14 h-14 rounded-2xl bg-[#31523D] text-[#D0A73B] border border-[#D0A73B]/30 flex items-center justify-center shadow-md animate-bounce mb-4">
          <Sparkles className="w-7 h-7" />
        </div>
        <div className="flex items-center space-x-2 text-[#31523D] font-bold text-sm">
          <RefreshCw className="w-4 h-4 animate-spin text-[#5F6D33]" />
          <span>Carregando Fisiolys Fisioterapia e Pilates...</span>
        </div>
      </div>
    );
  }

  if (error || !clinic || !schedule) {
    return (
      <div className="min-h-screen bg-[#F7F8F3] flex flex-col items-center justify-center p-4">
        <div className="max-w-md bg-white rounded-2xl p-6 shadow-sm border border-[#C9D8CB] text-center">
          <AlertCircle className="w-10 h-10 text-red-500 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-800">Falha ao Conectar</h3>
          <p className="text-xs text-slate-500 mt-1 mb-4">{error || "Não foi possível carregar a configuração inicial."}</p>
          <button
            onClick={loadData}
            className="px-4 py-2 bg-[#31523D] hover:bg-[#23372B] text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
          >
            Tentar Novamente
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F7F8F3] text-slate-800 font-sans antialiased selection:bg-[#F5EED3] selection:text-[#7E611D]">
      
      {/* Top Header with Search, Settings & Tabs */}
      <Header
        currentView={currentView}
        onViewChange={handleViewChange}
        clinic={clinic}
        isAdminAuthenticated={isAdminAuthenticated}
        onAdminLoginSuccess={handleAdminLoginSuccess}
        onAdminLogout={handleAdminLogout}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Main View Area */}
      <main>
        {currentView === 'public' && (
          <PublicBooking
            clinic={clinic}
            services={services}
            initialService={preselectedService}
            onBookingSuccess={loadData}
            onNavigateToServices={() => {
              setCurrentView('services');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onNavigateToPatientPortal={(tab?: string) => {
              if (tab === 'checkin') {
                setPatientPortalInitialTab('checkin');
              } else {
                setPatientPortalInitialTab('frequencia');
              }
              setCurrentView('patient_portal');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {currentView === 'services' && (
          <ServicesCatalogView
            clinic={clinic}
            services={services}
            onSelectServiceToBook={(service) => {
              setPreselectedService(service);
              setCurrentView('public');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {currentView === 'patient_portal' && (
          <PatientPortal
            clinic={clinic}
            services={services}
            appointments={appointments}
            patients={patients}
            loyaltyMembers={loyaltyMembers}
            initialTab={patientPortalInitialTab}
            onNavigateToBooking={() => {
              setPreselectedService(null);
              setCurrentView('public');
            }}
            onReload={loadData}
          />
        )}

        {currentView === 'admin' && (
          isAdminAuthenticated ? (
            <AdminDashboard
              clinic={clinic}
              services={services}
              schedule={schedule}
              appointments={appointments}
              patients={patients}
              onReload={loadData}
            />
          ) : (
            <div className="max-w-md mx-auto my-20 p-8 bg-white rounded-3xl border border-[#D0A73B]/40 shadow-xl text-center space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-[#31523D] text-[#D0A73B] flex items-center justify-center mx-auto shadow-md">
                <Lock className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-extrabold text-slate-900">Acesso Restrito ao Painel Gestor</h2>
              <p className="text-xs text-slate-500 leading-relaxed">
                Esta área exige a senha de segurança da administração da <strong>Dra. Elays Marinho</strong>.
              </p>
              <button
                onClick={() => setCurrentView('patient_portal')}
                className="px-5 py-2.5 bg-[#31523D] hover:bg-[#23372B] text-white font-bold rounded-xl text-xs transition-all shadow-xs cursor-pointer"
              >
                Ir para Gestão do Paciente
              </button>
            </div>
          )
        )}
      </main>

      {/* GLOBAL SEARCH MODAL (Lupa de Busca) */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        patients={patients}
        appointments={appointments}
        services={services}
        loyaltyMembers={loyaltyMembers}
        onNavigate={handleSearchNavigate}
      />

      {/* QUICK SETTINGS & PASSWORDS MODAL */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        clinic={clinic}
      />

    </div>
  );
}
