/**
 * Security and Password Management Utilities for Fisiolys
 * Uses Supabase Auth. No administrative password is stored in the browser.
 */
import { requireSupabase } from '../services/supabaseClient';

export const DEFAULT_ADMIN_PASSWORD = '';

export const DEFAULT_DOCTOR_CPF = '';

const STORAGE_DOCTOR_CPF_KEY = 'fisiolys_dr_cpf';

/**
 * Gets the current configured password for Admin Panel access.
 * Legacy compatibility getter; passwords are never returned to the client.
 */
export function getAdminPassword(): string {
  return '';
}

/**
 * Sets a new password for Admin Panel access.
 */
export function setAdminPassword(newPassword: string): boolean {
  void newPassword;
  return false;
}

/**
 * Gets the configured password for the Financial Module.
 * If not specifically set, falls back to the main Admin Password.
 */
export function getFinancialPassword(): string {
  return '';
}

/**
 * Sets a specific password for the Financial Module.
 */
export function setFinancialPassword(newPassword: string): boolean {
  void newPassword;
  return false;
}

/**
 * Verifies if entered password matches the current Admin password.
 */
export async function verifyAdminPassword(entered: string): Promise<boolean> {
  const email = import.meta.env.VITE_ADMIN_EMAIL as string | undefined;
  if (!email || !entered.trim()) return false;
  const { error } = await requireSupabase().auth.signInWithPassword({ email, password: entered });
  return !error;
}

/**
 * Verifies if entered password matches the Financial Module password.
 */
export async function verifyFinancialPassword(entered: string): Promise<boolean> {
  return verifyAdminPassword(entered);
}

/**
 * Legacy compatibility action; password resets happen in Supabase Auth.
 */
export function resetPasswordsToDefault(): void {
  console.warn('Redefina a senha pelo Supabase Auth.');
}

/**
 * Gets the doctor's registered CPF for official receipts and certificates.
 */
export function getDoctorCpf(fallback: string = DEFAULT_DOCTOR_CPF): string {
  try {
    const saved = localStorage.getItem(STORAGE_DOCTOR_CPF_KEY);
    if (saved && saved.trim().length > 0 && !saved.includes('000.000.000-00')) {
      return saved.trim();
    }
  } catch (e) {
    console.error('Error reading doctor CPF', e);
  }
  return fallback;
}

/**
 * Sets the doctor's registered CPF.
 */
export function setDoctorCpf(cpf: string): void {
  try {
    localStorage.setItem(STORAGE_DOCTOR_CPF_KEY, cpf.trim());
  } catch (e) {
    console.error('Error saving doctor CPF', e);
  }
}

const STORAGE_PROFESSIONAL_SIGNATURE_KEY = 'fisiolys_dr_signature';

/**
 * Gets the stored digital signature DataURL for Dra. Elays Marinho.
 */
export function getProfessionalSignature(): string | null {
  try {
    const saved = localStorage.getItem(STORAGE_PROFESSIONAL_SIGNATURE_KEY);
    if (saved && saved.startsWith('data:image')) {
      return saved;
    }
  } catch (e) {
    console.error('Error reading professional signature', e);
  }
  return null;
}

/**
 * Saves the professional digital signature for Dra. Elays Marinho.
 */
export function setProfessionalSignature(dataUrl: string): void {
  try {
    if (dataUrl && dataUrl.startsWith('data:image')) {
      localStorage.setItem(STORAGE_PROFESSIONAL_SIGNATURE_KEY, dataUrl);
    }
  } catch (e) {
    console.error('Error saving professional signature', e);
  }
}

/**
 * Clears the stored professional signature.
 */
export function clearProfessionalSignature(): void {
  try {
    localStorage.removeItem(STORAGE_PROFESSIONAL_SIGNATURE_KEY);
  } catch (e) {
    console.error('Error clearing professional signature', e);
  }
}
