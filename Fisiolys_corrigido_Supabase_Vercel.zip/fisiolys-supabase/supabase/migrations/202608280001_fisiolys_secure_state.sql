-- Persistência central do Fisiolys. Execute no SQL Editor do Supabase.
create table if not exists public.fisiolys_app_state (
  id text primary key,
  payload jsonb not null default '{}'::jsonb,
  revision bigint not null default 0,
  updated_at timestamptz not null default now()
);

alter table public.fisiolys_app_state enable row level security;

revoke all on table public.fisiolys_app_state from anon, authenticated;
grant select, insert, update on table public.fisiolys_app_state to service_role;

insert into public.fisiolys_app_state (id, payload)
values ('primary', '{}'::jsonb)
on conflict (id) do nothing;

create or replace function public.save_fisiolys_state(
  expected_revision bigint,
  new_payload jsonb
)
returns bigint
language plpgsql
security invoker
set search_path = public
as $$
declare
  next_revision bigint;
begin
  update public.fisiolys_app_state
     set payload = new_payload,
         revision = revision + 1,
         updated_at = now()
   where id = 'primary'
     and revision = expected_revision
  returning revision into next_revision;

  if next_revision is null then
    raise exception 'O cadastro foi alterado por outra sessão. Atualize e tente novamente.'
      using errcode = '40001';
  end if;

  return next_revision;
end;
$$;

revoke all on function public.save_fisiolys_state(bigint, jsonb) from public, anon, authenticated;
grant execute on function public.save_fisiolys_state(bigint, jsonb) to service_role;
