# Fisiolys — ativação do banco e publicação

Esta versão substitui o armazenamento local por Supabase e protege as rotas clínicas com Supabase Auth.

## 1. Criar o banco

1. Crie um projeto no Supabase.
2. Abra **SQL Editor**.
3. Execute o arquivo `supabase/migrations/202608280001_fisiolys_secure_state.sql`.
4. Confirme que a tabela `fisiolys_app_state` foi criada com RLS habilitado.

O navegador não recebe permissão direta sobre essa tabela. Somente o backend, usando a chave secreta, consegue ler e gravar.

## 2. Criar a conta administrativa

1. No Supabase, abra **Authentication > Users**.
2. Crie manualmente a usuária administrativa com seu e-mail e uma senha forte.
3. Mantenha o cadastro público de usuários desativado, pois qualquer conta do projeto não deve virar administradora.

## 3. Configurar a Vercel

Em **Project Settings > Environment Variables**, adicione:

- `SUPABASE_URL`: URL do projeto Supabase.
- `SUPABASE_SECRET_KEY`: chave secreta do servidor. Nunca use prefixo `VITE_` nela.
- `ADMIN_EMAIL`: e-mail exato da conta administrativa.
- `VITE_SUPABASE_URL`: a mesma URL pública do projeto.
- `VITE_SUPABASE_PUBLISHABLE_KEY`: chave publicável do projeto.
- `VITE_ADMIN_EMAIL`: o mesmo e-mail administrativo.
- `NODE_ENV`: `production`.
- `APP_URL`: endereço final do site.
- `GEMINI_API_KEY`: opcional, somente se os recursos de IA forem utilizados.

Não coloque `SUPABASE_SECRET_KEY` em arquivos do frontend, no GitHub ou em variáveis iniciadas por `VITE_`.

## 4. Publicar

1. Envie esta pasta para um repositório privado.
2. Importe o repositório na Vercel.
3. Confirme o framework Vite, comando `npm run build` e pasta de saída `dist`.
4. Faça o deploy somente depois de cadastrar todas as variáveis.

## 5. Teste obrigatório antes de substituir o site atual

1. Abra o endereço de teste da Vercel.
2. Faça um agendamento identificado claramente como teste.
3. Entre na área administrativa com a conta do Supabase.
4. Confirme o registro em outro aparelho ou navegador.
5. Atualize a página e confirme que ele continua disponível.
6. Exclua o registro de teste.

## Observações de segurança

- A antiga senha fixa foi removida do código.
- Erros de servidor não são mais tratados como “salvo com sucesso”.
- Consultas administrativas exigem token válido e o e-mail configurado em `ADMIN_EMAIL`.
- O portal do paciente não deve consultar prontuários apenas por CPF ou telefone. Nesta versão, essas consultas ficam protegidas até ser implantada verificação por código enviado ao paciente.
- Registros que estejam apenas no `localStorage` do navegador antigo não migram automaticamente. Eles precisam ser exportados e importados de forma controlada antes da troca definitiva.
