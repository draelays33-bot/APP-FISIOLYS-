import React, { useState, useEffect } from 'react';
import { 
  Users, Smartphone, Upload, FileText, Check, X, AlertCircle, 
  Sparkles, Plus, Download, RefreshCw, Share2, Phone, Search, CheckSquare, Calendar
} from 'lucide-react';
import { 
  isContactPickerSupported, pickNativeChromeContacts, 
  parseVCardText, parsePastedContacts, exportLeadsToVCard,
  ImportedContact 
} from '../../utils/contactUtils';
import { CrmLead } from '../../types';

interface CrmContactSyncModalProps {
  existingLeads: CrmLead[];
  onImportContacts: (contacts: ImportedContact[]) => Promise<void>;
  onClose: () => void;
}

export const CrmContactSyncModal: React.FC<CrmContactSyncModalProps> = ({
  existingLeads,
  onImportContacts,
  onClose
}) => {
  const [activeMode, setActiveMode] = useState<'chrome' | 'file' | 'paste' | 'export'>('chrome');
  const [isSupported, setIsSupported] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  const [parsedContacts, setParsedContacts] = useState<ImportedContact[]>([]);
  const [selectedIndices, setSelectedIndices] = useState<number[]>([]);
  const [pasteText, setPasteText] = useState('');
  const [defaultProtocol, setDefaultProtocol] = useState('Pilates clássico');
  const [searchFilter, setSearchFilter] = useState('');

  useEffect(() => {
    setIsSupported(isContactPickerSupported());
    if (!isContactPickerSupported()) {
      setActiveMode('file');
    }
  }, []);

  // 1. Chrome Native Contact Picker
  const handlePickFromChrome = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const res = await pickNativeChromeContacts();
      if (res.success && res.contacts.length > 0) {
        setParsedContacts(res.contacts);
        setSelectedIndices(res.contacts.map((_, i) => i));
      } else if (!res.success && res.error) {
        setErrorMessage(res.error);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Erro ao abrir a agenda de contatos.');
    } finally {
      setIsLoading(false);
    }
  };

  // 2. File Upload (.vcf or .csv)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMessage(null);
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (!content) return;

      let contacts: ImportedContact[] = [];
      if (file.name.toLowerCase().endsWith('.vcf') || file.name.toLowerCase().endsWith('.vcard')) {
        contacts = parseVCardText(content);
      } else {
        contacts = parsePastedContacts(content);
      }

      if (contacts.length === 0) {
        setErrorMessage('Nenhum contato válido encontrado no arquivo. Verifique o formato (.vcf ou .csv).');
      } else {
        setParsedContacts(contacts);
        setSelectedIndices(contacts.map((_, i) => i));
      }
    };
    reader.readAsText(file);
  };

  // 3. Parse Pasted Text
  const handleParsePasted = () => {
    if (!pasteText.trim()) return;
    const contacts = parsePastedContacts(pasteText);
    if (contacts.length === 0) {
      setErrorMessage('Nenhum contato identificado no texto colado. Use o formato: Nome, (93) 99126-5006');
    } else {
      setErrorMessage(null);
      setParsedContacts(contacts);
      setSelectedIndices(contacts.map((_, i) => i));
    }
  };

  // Selection toggle
  const toggleSelectAll = () => {
    if (selectedIndices.length === filteredContacts.length) {
      setSelectedIndices([]);
    } else {
      setSelectedIndices(filteredContacts.map((_, i) => i));
    }
  };

  const toggleSelectOne = (index: number) => {
    setSelectedIndices(prev => 
      prev.includes(index) ? prev.filter(i => i !== index) : [...prev, index]
    );
  };

  const filteredContacts = parsedContacts.filter(c => 
    c.nome.toLowerCase().includes(searchFilter.toLowerCase()) ||
    c.telefone.includes(searchFilter)
  );

  // Check if contact already exists in CRM
  const isAlreadyInCrm = (tel: string) => {
    const clean = tel.replace(/\D/g, '');
    return existingLeads.some(l => l.telefone.replace(/\D/g, '').includes(clean) || clean.includes(l.telefone.replace(/\D/g, '')));
  };

  // Final Import
  const handleConfirmImport = async () => {
    const toImport = parsedContacts
      .filter((_, idx) => selectedIndices.includes(idx))
      .map(c => ({
        ...c,
        protocolo: c.protocolo || defaultProtocol
      }));

    if (toImport.length === 0) {
      alert('Selecione ao menos um contato para importar.');
      return;
    }

    setIsLoading(true);
    try {
      await onImportContacts(toImport);
      alert(`🎉 Sucesso! ${toImport.length} contatos foram adicionados como leads no CRM.`);
      onClose();
    } catch (e) {
      alert('Erro ao importar contatos para o CRM.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-[#FAF7F0] rounded-3xl w-full max-w-3xl border border-[#E4DCC8] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Top Header */}
        <div className="bg-[#1B2E24] text-[#FAF7F0] p-5 flex items-center justify-between border-b border-[#16251D]">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-[#243F30] text-[#DCC58F] flex items-center justify-center border border-[#B08A3E]/40">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-serif font-bold">
                Conectar Contatos do WhatsApp & Google
              </h3>
              <p className="text-xs text-[#C9D1C8]">
                Sincronize contatos da agenda do celular e WhatsApp direto para o CRM de Leads.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-[#C9D1C8] hover:text-white rounded-xl hover:bg-[#20372B] transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector Tabs */}
        <div className="p-3 bg-[#F3EEE2] border-b border-[#E4DCC8] flex flex-wrap gap-2">
          <button
            onClick={() => { setActiveMode('chrome'); setErrorMessage(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 cursor-pointer ${
              activeMode === 'chrome' 
                ? 'bg-[#1B2E24] text-[#DCC58F] shadow-xs' 
                : 'bg-white text-[#5B5A52] hover:bg-[#FAF7F0] border border-[#E4DCC8]'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-[#B08A3E]" />
            <span>Toque Direto no Celular (Chrome)</span>
          </button>

          <button
            onClick={() => { setActiveMode('file'); setErrorMessage(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 cursor-pointer ${
              activeMode === 'file' 
                ? 'bg-[#1B2E24] text-[#DCC58F] shadow-xs' 
                : 'bg-white text-[#5B5A52] hover:bg-[#FAF7F0] border border-[#E4DCC8]'
            }`}
          >
            <Upload className="w-3.5 h-3.5 text-[#B08A3E]" />
            <span>Importar Arquivo (.vcf / WhatsApp / CSV)</span>
          </button>

          <button
            onClick={() => { setActiveMode('paste'); setErrorMessage(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 cursor-pointer ${
              activeMode === 'paste' 
                ? 'bg-[#1B2E24] text-[#DCC58F] shadow-xs' 
                : 'bg-white text-[#5B5A52] hover:bg-[#FAF7F0] border border-[#E4DCC8]'
            }`}
          >
            <FileText className="w-3.5 h-3.5 text-[#B08A3E]" />
            <span>Colar Lista Rápida</span>
          </button>

          <button
            onClick={() => { setActiveMode('export'); setErrorMessage(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 cursor-pointer ${
              activeMode === 'export' 
                ? 'bg-[#1B2E24] text-[#DCC58F] shadow-xs' 
                : 'bg-white text-[#5B5A52] hover:bg-[#FAF7F0] border border-[#E4DCC8]'
            }`}
          >
            <Download className="w-3.5 h-3.5 text-[#B08A3E]" />
            <span>Exportar para Celular / Google</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          
          {/* 1. CHROME MOBILE CONTACT PICKER & GOOGLE SYNC */}
          {activeMode === 'chrome' && (
            <div className="space-y-4">
              <div className="p-4 bg-white rounded-2xl border border-[#E4DCC8] space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-[#1B2E24]">Agenda Nativa por Toque Direto (Google Chrome no Celular)</h4>
                    <p className="text-xs text-[#5B5A52] pt-0.5">
                      No Google Chrome no smartphone (Android/iOS), utilize o toque direto para sincronizar seus contatos do Google e abrir a agenda nativa do celular instantaneamente.
                    </p>
                  </div>
                </div>

                <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    id="btn-pick-native-chrome-contacts"
                    onClick={handlePickFromChrome}
                    disabled={isLoading}
                    className="px-4 py-3 bg-[#1B2E24] hover:bg-[#22392C] text-[#FAF7F0] text-xs font-bold rounded-xl shadow-md border border-[#DCC58F]/50 flex items-center justify-center space-x-2 transition-all cursor-pointer"
                  >
                    <Smartphone className="w-4 h-4 text-[#DCC58F]" />
                    <span>{isLoading ? 'Abrindo Agenda...' : '📱 Selecionar Contatos do Celular'}</span>
                  </button>

                  <a
                    id="btn-open-google-calendar-mobile"
                    href="https://calendar.google.com"
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-3 bg-[#243F30] hover:bg-[#2D4E3C] text-[#FAF7F0] text-xs font-bold rounded-xl border border-[#3E6550] flex items-center justify-center space-x-2 shadow-xs transition-all"
                  >
                    <Calendar className="w-4 h-4 text-[#DCC58F]" />
                    <span>📅 Abrir Google Agenda</span>
                  </a>

                  <a
                    id="btn-open-google-contacts-web"
                    href="https://contacts.google.com"
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2.5 bg-[#F3EEE2] hover:bg-[#ECE4D3] text-[#1B2E24] text-xs font-bold rounded-xl border border-[#E4DCC8] flex items-center justify-center space-x-1.5"
                  >
                    <Users className="w-3.5 h-3.5 text-[#B08A3E]" />
                    <span>Abrir Google Contatos</span>
                  </a>

                  <button
                    id="btn-quick-export-leads-vcf"
                    onClick={() => exportLeadsToVCard(existingLeads)}
                    className="px-4 py-2.5 bg-white hover:bg-[#FAF7F0] text-[#1B2E24] text-xs font-bold rounded-xl border border-[#E4DCC8] flex items-center justify-center space-x-1.5 shadow-2xs"
                  >
                    <Download className="w-3.5 h-3.5 text-[#B08A3E]" />
                    <span>Exportar Leads p/ Agenda (.vcf)</span>
                  </button>
                </div>

                <div className="p-3 bg-[#F8F5EE] rounded-xl border border-[#E4DCC8] text-xs text-[#5B5A52] flex items-start space-x-2">
                  <Sparkles className="w-4 h-4 text-[#B08A3E] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-[#1B2E24]">Como funciona o Toque Direto no Celular:</p>
                    <p className="text-[11px] text-[#736B5E]">
                      Ao tocar nos botões de agenda nos cards de pacientes do CRM, o Google Chrome abre o aplicativo nativo de calendário do seu smartphone já preenchendo o nome do paciente, telefone e procedimento de fisioterapia/pilates.
                    </p>
                  </div>
                </div>

                {!isSupported && (
                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-start space-x-2">
                    <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold">Dica de Compatibilidade:</p>
                      <p className="text-[11px]">
                        A API de toque direto está ativa no Google Chrome para celular. No computador ou outros navegadores, você também pode exportar os contatos do Google e importar o arquivo (.vcf / .csv) na aba ao lado.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 2. FILE UPLOAD (.vcf / .csv) */}
          {activeMode === 'file' && (
            <div className="space-y-4">
              <div className="p-6 bg-white rounded-2xl border-2 border-dashed border-[#B08A3E]/60 text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-[#F3EEE2] text-[#B08A3E] flex items-center justify-center mx-auto">
                  <Upload className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-[#1B2E24]">Importar arquivo de Contatos do WhatsApp ou Google (.vcf / .csv)</h4>
                  <p className="text-xs text-[#736B5E] max-w-md mx-auto pt-1">
                    Exporte seus contatos do Google Contatos (formato vCard / .vcf) ou WhatsApp e arraste para cá.
                  </p>
                </div>

                <label className="inline-block px-5 py-2.5 bg-[#1B2E24] hover:bg-[#22392C] text-[#FAF7F0] text-xs font-bold rounded-xl shadow-md border border-[#DCC58F]/50 cursor-pointer transition-all">
                  <span>Selecionar Arquivo do Dispositivo</span>
                  <input
                    type="file"
                    accept=".vcf,.vcard,.csv,.txt"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          )}

          {/* 3. PASTE TEXT */}
          {activeMode === 'paste' && (
            <div className="space-y-3">
              <label className="block text-xs font-bold text-[#1B2E24]">
                Cole contatos copiados do WhatsApp ou lista de pacientes:
              </label>
              <textarea
                value={pasteText}
                onChange={(e) => setPasteText(e.target.value)}
                placeholder="Exemplo:&#10;Maria Fernanda Silva, (93) 99126-5006, Pilates clássico&#10;Carlos Eduardo, 93988776655, Fisioterapia Coluna&#10;Patrícia Lima, 93991234567"
                rows={5}
                className="w-full p-3 rounded-2xl bg-white border border-[#E4DCC8] text-xs font-mono focus:ring-2 focus:ring-[#B08A3E] outline-none"
              />
              <button
                onClick={handleParsePasted}
                className="px-4 py-2 bg-[#1B2E24] text-[#FAF7F0] text-xs font-bold rounded-xl shadow-xs"
              >
                Processar Contatos
              </button>
            </div>
          )}

          {/* 4. EXPORT TO PHONE / GOOGLE */}
          {activeMode === 'export' && (
            <div className="p-5 bg-white rounded-2xl border border-[#E4DCC8] space-y-3">
              <div className="flex items-start space-x-3">
                <div className="w-10 h-10 rounded-2xl bg-[#DCC58F]/30 text-[#1B2E24] flex items-center justify-center shrink-0">
                  <Download className="w-5 h-5 text-[#B08A3E]" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-[#1B2E24]">Sincronizar Leads do CRM com seu Celular</h4>
                  <p className="text-xs text-[#5B5A52]">
                    Baixe o arquivo de contatos vCard (.vcf) contendo todos os {existingLeads.length} leads do CRM para adicionar à agenda do seu smartphone com 1 toque.
                  </p>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => exportLeadsToVCard(existingLeads)}
                  className="px-5 py-2.5 bg-[#1B2E24] hover:bg-[#22392C] text-[#FAF7F0] text-xs font-bold rounded-xl shadow-md border border-[#DCC58F]/50 flex items-center space-x-2"
                >
                  <Download className="w-4 h-4 text-[#DCC58F]" />
                  <span>Baixar Contatos para o Celular (.vcf)</span>
                </button>
              </div>
            </div>
          )}

          {errorMessage && (
            <div className="p-3.5 bg-rose-50 rounded-2xl border border-rose-200 text-xs text-rose-800 flex items-start space-x-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* PARSED CONTACTS PREVIEW & IMPORT LIST */}
          {parsedContacts.length > 0 && (
            <div className="pt-4 border-t border-[#E4DCC8] space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="text-sm font-bold text-[#1B2E24]">
                    Contatos Identificados ({parsedContacts.length})
                  </h4>
                  <span className="text-xs text-[#736B5E]">
                    {selectedIndices.length} selecionados para importação
                  </span>
                </div>

                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-[#736B5E] absolute left-2.5 top-2.5" />
                    <input
                      type="text"
                      value={searchFilter}
                      onChange={(e) => setSearchFilter(e.target.value)}
                      placeholder="Filtrar..."
                      className="pl-8 pr-3 py-1 bg-white border border-[#E4DCC8] rounded-xl text-xs outline-none"
                    />
                  </div>

                  <button
                    onClick={toggleSelectAll}
                    className="px-3 py-1.5 bg-[#F3EEE2] text-[#1B2E24] text-xs font-bold rounded-xl border border-[#E4DCC8]"
                  >
                    {selectedIndices.length === filteredContacts.length ? 'Desmarcar Todos' : 'Marcar Todos'}
                  </button>
                </div>
              </div>

              {/* Protocol selector for imported leads */}
              <div className="p-3 bg-[#F3EEE2] rounded-2xl border border-[#E4DCC8] flex items-center justify-between text-xs">
                <span className="font-semibold text-[#1B2E24]">Tratamento Padrão:</span>
                <select
                  value={defaultProtocol}
                  onChange={(e) => setDefaultProtocol(e.target.value)}
                  className="p-1.5 bg-white border border-[#E4DCC8] rounded-xl text-xs font-medium"
                >
                  <option value="Pilates clássico">Pilates clássico</option>
                  <option value="Fisioterapia traumato-ortopédica">Fisioterapia traumato-ortopédica</option>
                  <option value="Tratamento de coluna e postura">Tratamento de coluna e postura</option>
                  <option value="Liberação miofascial">Liberação miofascial</option>
                  <option value="Avaliação postural">Avaliação postural</option>
                </select>
              </div>

              {/* Contacts Table/List */}
              <div className="max-h-60 overflow-y-auto space-y-2 border border-[#E4DCC8] rounded-2xl p-2 bg-white">
                {filteredContacts.map((contact, idx) => {
                  const isSelected = selectedIndices.includes(idx);
                  const exists = isAlreadyInCrm(contact.telefone);

                  return (
                    <div
                      key={idx}
                      onClick={() => toggleSelectOne(idx)}
                      className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                        isSelected 
                          ? 'bg-[#F8F5EE] border-[#B08A3E]' 
                          : 'bg-white border-[#E4DCC8]/60 opacity-80'
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => {}} // Handled by parent div
                          className="w-4 h-4 rounded text-[#1B2E24] border-[#8C8270]"
                        />
                        <div>
                          <p className="text-xs font-bold text-[#1B2E24]">{contact.nome}</p>
                          <span className="text-[11px] text-[#736B5E] font-mono">{contact.telefone}</span>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        {exists && (
                          <span className="px-2 py-0.5 bg-amber-100 text-amber-800 text-[10px] font-bold rounded-full border border-amber-200">
                            Já no CRM
                          </span>
                        )}
                        <span className="text-[11px] text-[#8C8270]">
                          {contact.origem}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[#F3EEE2] border-t border-[#E4DCC8] flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white border border-[#E4DCC8] text-[#736B5E] hover:text-[#1B2E24] text-xs font-bold rounded-xl"
          >
            Fechar
          </button>

          {parsedContacts.length > 0 && (
            <button
              onClick={handleConfirmImport}
              disabled={isLoading || selectedIndices.length === 0}
              className="px-5 py-2.5 bg-[#1B2E24] hover:bg-[#22392C] text-[#FAF7F0] text-xs font-bold rounded-xl shadow-md border border-[#DCC58F]/50 flex items-center space-x-2 disabled:opacity-50"
            >
              <Check className="w-4 h-4 text-[#DCC58F]" />
              <span>Importar {selectedIndices.length} Leads para o CRM</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
